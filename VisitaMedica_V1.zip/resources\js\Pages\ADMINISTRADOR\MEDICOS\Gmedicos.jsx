import React, { useState } from 'react';
import { Head, router, Deferred } from '@inertiajs/react';
import PanelAdmin from '../PanelAdmin';

// Hooks
import { useMedicosFilter } from './Hooks/useMedicosFilter';
import { useMedicosSelection } from './Hooks/useMedicosSelection';
import { useMedicosImport } from './Hooks/useMedicosImport';
import { useMedicoForm } from './Hooks/useMedicoForm';

// Componentes UI
import MedicosToolbar from './Components/MedicosToolbar';
import MedicosTable from './Components/MedicosTable';

// Modales
import MedicoFormModal from './Components/MedicoFormModal';
import ExportConfirmModal from './Components/ExportConfirmModal';
import ImportPreviewModal from './Components/ImportPreviewModal';
import ImportWarningModal from './Components/ImportWarningModal';
import DeleteConfirmModal from './Components/DeleteConfirmModal';
import AssignVisitorModal from './Components/AssignVisitorModal';
import ReviewSelectionModal from './Components/ReviewSelectionModal';
import MedicoViewModal from './Components/MedicoViewModal';
import VisitasDetalleModal from './Components/VisitasDetalleModal';

const MESES_NOMBRES = {
    '1': 'Enero', '2': 'Febrero', '3': 'Marzo', '4': 'Abril',
    '5': 'Mayo', '6': 'Junio', '7': 'Julio', '8': 'Agosto',
    '9': 'Septiembre', '10': 'Octubre', '11': 'Noviembre', '12': 'Diciembre',
    'todos': 'Todos los Meses'
};

const Gmedicos = ({
    auth,
    medicos = [],
    visitadores = [],
    tiposDocumento = [],
    categorias = [],
    filtroVisitador = null,
    filtroMes = null,
    filtroAnio = null,
    filtroFechaDesde = null,
    filtroFechaHasta = null,
    modoFiltro = 'mes',
}) => {
    // --- Hooks ---
    const filter = useMedicosFilter(medicos);
    const selection = useMedicosSelection();
    const importHook = useMedicosImport(medicos, visitadores);
    const form = useMedicoForm(visitadores);

    // --- Estado de modales simples ---
    const [isExportModalOpen, setIsExportModalOpen] = useState(false);
    const [isExporting, setIsExporting] = useState(false); // ← Estado para el modal de carga de exportación
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
    const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
    const [isViewModalOpen, setIsViewModalOpen] = useState(false);
    const [selectedMedico, setSelectedMedico] = useState(null);

    // Modal de resumen de visitas por médico
    const [isVisitasModalOpen, setIsVisitasModalOpen] = useState(false);
    const [selectedMedicoVisitas, setSelectedMedicoVisitas] = useState(null);

    const handleMesChange = (nuevoMes) => {
        const queryParams = {};
        if (filtroVisitador) {
            queryParams.visitador_id = filtroVisitador.id;
        }
        if (nuevoMes) {
            queryParams.mes = nuevoMes;
        }
        router.get(route('Gmedicos.index'), queryParams, {
            preserveState: true,
            preserveScroll: true,
        });
    };

    const handleFechaRangeChange = (desde, hasta) => {
        if (!desde || !hasta) return;
        const queryParams = {};
        if (filtroVisitador) {
            queryParams.visitador_id = filtroVisitador.id;
        }
        queryParams.fecha_desde = desde;
        queryParams.fecha_hasta = hasta;

        router.get(route('Gmedicos.index'), queryParams, {
            preserveState: true,
            preserveScroll: true,
        });
    };

    const handleClearRangoDates = () => {
        const queryParams = {};
        if (filtroVisitador) {
            queryParams.visitador_id = filtroVisitador.id;
        }
        queryParams.mes = filtroMes || 'todos';
        router.get(route('Gmedicos.index'), queryParams, {
            preserveState: true,
            preserveScroll: true,
        });
    };

    const handleOpenVisitasModal = (medico) => {
        setSelectedMedicoVisitas(medico);
        setIsVisitasModalOpen(true);
    };


    // --- Datos derivados ---
    const medicosSeleccionados = medicos.filter(m => selection.selectedIds.includes(m.id));
    const hasPreviousAssignment = medicosSeleccionados.some(m => m.visitador_id !== null);

    // --- Handlers ---
    const executeExport = () => {
    // 1. Cerramos el modal de confirmación y abrimos el modal de carga
    setIsExportModalOpen(false);
    setIsExporting(true);

    // 2. Generamos un token único de identificación
    const downloadToken = new Date().getTime().toString();

    const form = document.createElement('form');
    form.method = 'POST';
    form.action = route('Gmedicos.exportar');
    form.style.display = 'none';

    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content;
    if (csrfToken) {
        const csrfInput = document.createElement('input');
        csrfInput.type = 'hidden';
        csrfInput.name = '_token';
        csrfInput.value = csrfToken;
        form.appendChild(csrfInput);
    }

    // 3. Adjuntamos el token al formulario HTML
    const tokenInput = document.createElement('input');
    tokenInput.type = 'hidden';
    tokenInput.name = 'download_token';
    tokenInput.value = downloadToken;
    form.appendChild(tokenInput);

    if (selection.selectedIds.length > 0) {
        const idsInput = document.createElement('input');
        idsInput.type = 'hidden';
        idsInput.name = 'ids';
        idsInput.value = selection.selectedIds.join(',');
        form.appendChild(idsInput);
    }

    document.body.appendChild(form);
    form.submit();
    document.body.removeChild(form);

    // 4. Verificación continua (Polling):
    // Se ejecuta cada 300ms revisando si la cookie 'download_token' ya fue escrita por Laravel
    const checkCookieInterval = setInterval(() => {
        if (document.cookie.indexOf(`download_token=${downloadToken}`) !== -1) {
            // ¡La descarga inició en el navegador! Cerramos el modal
            setIsExporting(false);
            clearInterval(checkCookieInterval);

            // Limpiamos la cookie borrándola del navegador
            document.cookie = `download_token=${downloadToken}; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
        }
    }, 300);
};
    const handleOpenDelete = () => {
        if (selection.selectedIds.length === 0) return;
        setIsDeleteModalOpen(true);
    };

    const executeDelete = () => {
        router.post(route('medicos.eliminar-masivo'), { ids: selection.selectedIds }, {
            onSuccess: () => { setIsDeleteModalOpen(false); selection.clearSelection(); },
        });
    };

    const handleOpenAssign = () => {
        if (selection.selectedIds.length === 0) return;
        if (hasPreviousAssignment) {
            setIsReviewModalOpen(true);
        } else {
            setIsAssignModalOpen(true);
        }
    };

    const handleReviewConfirm = (idsConfirmados) => {
        selection.setSelectedIds(idsConfirmados);
        setIsReviewModalOpen(false);
        setIsAssignModalOpen(true);
    };

    const executeAssignVisitor = (visitadorId) => {
        router.post(route('medicos.vincular-visitador'), {
            medico_ids: selection.selectedIds,
            visitador_id: visitadorId,
        }, {
            onSuccess: () => { setIsAssignModalOpen(false); selection.clearSelection(); },
            preserveScroll: true,
        });
    };

    const openViewModal = (medico) => {
        setSelectedMedico(medico);
        setIsViewModalOpen(true);
    };

    return (
        <PanelAdmin>
            <Head title="Directorio de Médicos" />

            <div className="w-full min-h-screen flex flex-col bg-white">
                <MedicosToolbar
                    searchTerm={filter.searchTerm}
                    onSearchChange={filter.setSearchTerm}
                    selectedIds={selection.selectedIds}
                    onDelete={handleOpenDelete}
                    onAssignVisitor={handleOpenAssign}
                    onExport={() => setIsExportModalOpen(true)}
                    onTemplate={() => importHook.handleDownloadTemplate({ visitadores, tiposDocumento, categorias })}
                    onImport={importHook.handleImportClick}
                    onNew={form.openCreateModal}
                    fileInputRef={importHook.fileInputRef}
                    onFileChange={importHook.handleFileChange}

                    currentItems={filter.currentItems}
                    onSelectAll={selection.handleSelectAll}
                    itemsPerPage={filter.itemsPerPage}
                    onItemsPerPageChange={filter.setItemsPerPage}
                    currentPage={filter.currentPage}
                    onPageChange={filter.setCurrentPage}
                    totalPages={filter.totalPages}
                    soloSinVisitador={filter.soloSinVisitador}          
                    onToggleSoloSinVisitador={filter.setSoloSinVisitador} 
                    filtroMes={filtroMes}
                    onMesChange={handleMesChange}
                    fechaDesde={filtroFechaDesde}
                    fechaHasta={filtroFechaHasta}
                    onFechaRangeChange={handleFechaRangeChange}
                    onClearRangoDates={handleClearRangoDates}
                    modoFiltro={modoFiltro}
                />
{filtroVisitador && (
    <div className="mx-4 mt-12 mb-2 flex items-center justify-between rounded-xl border border-blue-100 bg-blue-50 px-4 py-2">
        <span className="text-[11px] font-bold uppercase tracking-wide text-slate-600">
            Mostrando médicos de:{' '}
            <span className="text-blue-700">
                {filtroVisitador.nombre} {filtroVisitador.apellido}
            </span>
        </span>
        <button
            onClick={() => router.get(route('Gmedicos.index'))}
            className="text-[11px] font-black uppercase tracking-wide text-blue-600 hover:underline"
        >
            Ver todos
        </button>
    </div>
)}
                {/* Envolvemos la tabla con Deferred para mostrar un indicador mientras cargan los médicos */}
                <Deferred data="medicos" fallback={<CargandoMedicosState />}>
                    <MedicosTable
                        currentItems={filter.currentItems}
                        selectedIds={selection.selectedIds}
                        onSelectOne={selection.handleSelectOne}
                        onEdit={form.openEditModal}
                        onView={openViewModal}
                        onVerVisitas={handleOpenVisitasModal}
                    />
                </Deferred>
            </div>

            {/* Modal / Overlay de Carga para Exportación */}
            {isExporting && <ExportLoadingModal />}

            {/* Modal de Detalle de Visitas por Médico */}
            <VisitasDetalleModal
                isOpen={isVisitasModalOpen}
                onClose={() => setIsVisitasModalOpen(false)}
                medico={selectedMedicoVisitas}
                nombreMes={
                    modoFiltro === 'rango' && filtroFechaDesde && filtroFechaHasta
                        ? `${filtroFechaDesde} al ${filtroFechaHasta}`
                        : (MESES_NOMBRES[filtroMes] || 'Mes Actual')
                }
            />

            {/* Modales */}
            <MedicoFormModal
                isOpen={form.isFormModalOpen}
                onClose={() => form.setIsFormModalOpen(false)}
                isEditing={form.isEditing}
                data={form.data}
                setData={form.setData}
                errors={form.errors}
                processing={form.processing}
                onSubmit={form.handleSubmit}
                tiposDocumento={tiposDocumento}
                visitadorNombre={form.visitadorNombre}
                visitadores={visitadores} 
            />

            <ExportConfirmModal
                isOpen={isExportModalOpen}
                onClose={() => setIsExportModalOpen(false)}
                onConfirm={executeExport}
                selectedIds={selection.selectedIds}
                medicos={medicos}
            />

            <ImportPreviewModal
                isOpen={importHook.isPreviewModalOpen}
                onClose={() => importHook.setIsPreviewModalOpen(false)}
                onConfirm={importHook.handleProcessImport}
                previewData={importHook.previewData}
                activeTab={importHook.activeTab}
                setActiveTab={importHook.setActiveTab}
            />

            <ImportWarningModal
                isOpen={importHook.isWarningModalOpen}
                duplicatesCount={importHook.duplicatesFound.length}
                onConfirm={importHook.executeServerImport}
                onCancel={() => importHook.setIsWarningModalOpen(false)}
            />

            <DeleteConfirmModal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={executeDelete}
                medicosSeleccionados={medicosSeleccionados}
            />

            <AssignVisitorModal
                isOpen={isAssignModalOpen}
                onClose={() => setIsAssignModalOpen(false)}
                onConfirm={executeAssignVisitor}
                visitadores={visitadores}
                selectedIds={selection.selectedIds}
                hasPreviousAssignment={hasPreviousAssignment}
            />

            <ReviewSelectionModal
                isOpen={isReviewModalOpen}
                onClose={() => setIsReviewModalOpen(false)}
                onConfirm={handleReviewConfirm}
                medicosSeleccionados={medicosSeleccionados}
            />

            <MedicoViewModal
                isOpen={isViewModalOpen}
                onClose={() => setIsViewModalOpen(false)}
                medico={selectedMedico}
            />
        </PanelAdmin>
    );
};

// Componente modal de carga para la exportación
const ExportLoadingModal = () => (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in">
        <div className="bg-white p-8 rounded-xl shadow-2xl flex flex-col items-center max-w-sm w-full mx-4 border border-gray-100">
            <svg className="animate-spin h-12 w-12 text-indigo-600 mb-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <h3 className="text-lg font-semibold text-gray-800">Generando archivo Excel...</h3>
            <p className="text-sm text-gray-500 text-center mt-2">
                Estamos preparando tus datos. La descarga comenzará automáticamente en unos instantes.
            </p>
        </div>
    </div>
);

// Componente visual para mostrar el estado de carga
const CargandoMedicosState = () => (
    <div className="flex flex-col items-center justify-center p-16 bg-white border border-gray-100 rounded-lg shadow-sm my-4">
        <svg className="animate-spin -ml-1 mr-3 h-10 w-10 text-indigo-600 mb-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <p className="text-gray-700 font-medium text-lg">Consultando médicos, espera...</p>
        <p className="text-gray-400 text-sm mt-1">Sincronizando información y especialidades con Odoo</p>
    </div>
);

export default Gmedicos;