import React, { useState } from 'react';
import { Head, router } from '@inertiajs/react';
import PanelAdmin from '../PanelAdmin';

// Hooks
import { useVisitasFilter } from './HooksV/useVisitasFilter';
import { useVisitaForm } from './HooksV/useVisitaForm';
import { useVisitasSelection } from './HooksV/useVisitasSelection';

// Componentes
import VisitasToolbar from './ComponentsV/VisitasToolbar';
import VisitasTable from './ComponentsV/VisitasTable';
import VisitaFormModal from './ComponentsV/VisitaFormModal';
import VisitaViewModal from './ComponentsV/VisitaViewModal';
import VisitaDeleteModal from './ComponentsV/VisitaDeleteModal';

const VisitasIndex = ({ auth, visitas = [], visitadores = [], productos = [] }) => {
    // 1. Inicialización de Hooks
    // Si visitas viene en formato array lo pasa directo; si viene paginado extrae .data
    const listaVisitas = Array.isArray(visitas) ? visitas : (visitas?.data || []);
    const filter = useVisitasFilter(listaVisitas, [], visitadores);
    const form = useVisitaForm(visitas);
    const selection = useVisitasSelection();

    const [bulkProcessing, setBulkProcessing] = useState(false);
    const [isBulkDeleteOpen, setIsBulkDeleteOpen] = useState(false);

    const handleBulkDelete = () => {
        if (selection.selectedIds.length === 0) return;
        setIsBulkDeleteOpen(true);
    };

    const confirmBulkDelete = () => {
        setBulkProcessing(true);
        router.delete(route('Gvisitas.destroyBulk'), {
            data: { ids: selection.selectedIds },
            onSuccess: () => {
                selection.clearSelection();
                setIsBulkDeleteOpen(false);
                setBulkProcessing(false);
            },
            onError: () => setBulkProcessing(false),
        });
    };

    const handleBulkExport = () => {};

    return (
        <PanelAdmin user={auth?.user}>
            <Head title="Gestión de Visitas" />

            <div className="w-full min-h-screen flex flex-col bg-white">
                {/* TOOLBAR: Conectado a filtros, paginación y selección masiva */}
                <VisitasToolbar
                    searchTerm={filter.searchTerm}
                    onSearchChange={filter.setSearchTerm}

                    selectedIds={selection.selectedIds}
                    onSelectAll={selection.toggleSelectAll}
                    currentItems={filter.currentItems}

                    currentPage={filter.currentPage}
                    onPageChange={filter.setCurrentPage}
                    totalPages={filter.totalPages}
                    itemsPerPage={filter.itemsPerPage}
                    onItemsPerPageChange={filter.setItemsPerPage}

                    onNew={form.openCreateModal}
                    onDelete={handleBulkDelete}
                    onExport={handleBulkExport}
                />

                {/* TABLA: Conectada a datos y selección individual por fila */}
                <VisitasTable
                    currentItems={filter.currentItems}
                    visitadores={visitadores}

                    selectedIds={selection.selectedIds}
                    onSelectOne={selection.toggleSelectOne}

                    onView={form.openViewModal}
                    onEdit={form.openEditModal}
                    onDelete={form.openDeleteModal}
                />
            </div>

            {/* MODALES DE GESTIÓN */}
            <VisitaFormModal
                isOpen={form.isModalOpen}
                onClose={() => form.setIsModalOpen(false)}
                onSubmit={form.handleSubmit}
                isEditing={form.isEditing}
                data={form.data}
                setData={form.setData}
                processing={form.processing}
                errors={form.errors}
                visitadores={visitadores}
                medicosFiltradosPorVisitador={form.medicosFiltradosPorVisitador}
                onFechaProgramadaChange={form.handleFechaProgramadaChange}
                onMedicoChange={form.handleMedicoChange}

                productos={productos}
            />

            <VisitaViewModal
                isOpen={form.isViewModalOpen}
                onClose={() => form.setIsViewModalOpen(false)}
                visita={form.selectedVisita}
                visitadores={visitadores}
            />

            <VisitaDeleteModal
                isOpen={form.isDeleteModalOpen}
                onClose={() => form.setIsDeleteModalOpen(false)}
                onConfirm={form.handleConfirmDelete}
                processing={form.processing}
            />

            {/* Modal eliminación masiva */}
            <VisitaDeleteModal
                isOpen={isBulkDeleteOpen}
                onClose={() => setIsBulkDeleteOpen(false)}
                onConfirm={confirmBulkDelete}
                processing={bulkProcessing}
            />
        </PanelAdmin>
    );
};

export default VisitasIndex;