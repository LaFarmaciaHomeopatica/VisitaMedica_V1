<?php

namespace App\Http\Controllers\administrador;

use App\Http\Controllers\Controller;
use App\Models\Medico;
use App\Models\Visitador;
use App\Models\TipoDocumento;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Exports\MedicosExport;
use App\Imports\MedicosImport;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Excel as ExcelFormat;
use App\Models\Categoria;
use Carbon\Carbon;
use App\Models\MedicoTemporal;
use App\Models\MedicoCategoriaHistorial;
use App\Services\OdooService;  // ← Service nuevo
use Illuminate\Support\Facades\Cookie;

class Medico2Controller extends Controller
{
    private OdooService $odoo;

    public function __construct(OdooService $odoo)
    {
        $this->odoo = $odoo;
    }

    // =========================================================================
    //  CRUD BÁSICO — Sin cambios
    // =========================================================================

 public function index()
{
    return Inertia::render('ADMINISTRADOR/MEDICOS/Gmedicos', [
        // Envolvemos los médicos en Inertia::defer
        'medicos' => Inertia::defer(function () {
            $medicos = Medico::with(['visitador', 'tipoDocumento', 'categoria'])->get();
            $this->inyectarEspecialidadOdoo($medicos);
            $this->inyectarTendenciaCategoria($medicos);
            return $medicos;
        }),
        'visitadores'    => Visitador::all(['id', 'nombre', 'apellido']),
        'tiposDocumento' => TipoDocumento::all(['id', 'codigo', 'nombre']),
        'categorias'     => Categoria::all(['id', 'nombre']),
    ]);
}

    /**
     * Agrega medico->categoria_tendencia ('subio'|'bajo'|'igual'|null) comparando
     * la categoría del último snapshot mensual contra la del mes anterior.
     */
    private function inyectarTendenciaCategoria(iterable $medicos): void
    {
        $medicoIds = collect($medicos)->pluck('id')->all();

        $historialPorMedico = MedicoCategoriaHistorial::with('categoria:id,valor_minimo')
            ->whereIn('medico_id', $medicoIds)
            ->orderByDesc('mes')
            ->get()
            ->groupBy('medico_id');

        foreach ($medicos as $medico) {
            $items = $historialPorMedico->get($medico->id);
            $medico->categoria_tendencia = $items
                ? $this->calcularTendenciaCategoria($items->get(0), $items->get(1))
                : null;
        }
    }

    private function calcularTendenciaCategoria(?MedicoCategoriaHistorial $actual, ?MedicoCategoriaHistorial $anterior): ?string
    {
        if (!$actual || !$anterior) return null;

        $vActual   = optional($actual->categoria)->valor_minimo;
        $vAnterior = optional($anterior->categoria)->valor_minimo;
        if ($vActual === null || $vAnterior === null) return null;

        if ((float) $vActual > (float) $vAnterior) return 'subio';
        if ((float) $vActual < (float) $vAnterior) return 'bajo';
        return 'igual';
    }

    /**
     * Últimos N snapshots mensuales de categoría de un médico, más reciente primero.
     */
    private function obtenerHistorialCategoria(Medico $medico, int $meses = 12)
    {
        return $medico->categoriaHistorial()
            ->with('categoria:id,nombre,valor_minimo')
            ->take($meses)
            ->get();
    }

    /**
     * true si el médico pertenece a la categoría de mayor rango (mayor
     * valor_minimo). No asumir que esa categoría siempre tiene id=1: en
     * /Gcategorias el admin puede crear/reordenar categorías libremente.
     */
    private function esCategoriaTope(?int $categoriaId): bool
    {
        if (!$categoriaId) return false;

        $topeId = Categoria::orderByDesc('valor_minimo')->value('id');

        return $topeId !== null && $categoriaId === $topeId;
    }

    // =========================================================================
    //  COMPARATIVA "PROMEDIO ÚLTIMOS 6 MESES" — Nuevo
    // =========================================================================
    /**
     * Calcula, por código de producto, el promedio mensual de compra y
     * formulación de los 6 meses completos inmediatamente anteriores al
     * mes actual, y lo compara (en %) contra el mes actual.
     *
     * No reemplaza la comparativa por mes seleccionado: es un dato adicional.
     */
    private function calcularPromedioSeisMeses(string $documento, Carbon $hoyReal, string $inicioMesActualStr, string $finMesActualStr): array
    {
        $inicioMesActual = Carbon::parse($inicioMesActualStr);

        // 6 meses completos justo antes del mes actual
        $finPromedio    = $inicioMesActual->copy()->subDay()->endOfMonth();
        $inicioPromedio = $inicioMesActual->copy()->subMonths(6)->startOfMonth();

        $rangoPromedioLabel = ucfirst($inicioPromedio->locale('es')->isoFormat('MMM YYYY'))
            . ' – ' . ucfirst($finPromedio->locale('es')->isoFormat('MMM YYYY'));

        // ── Comprado: reutilizamos getProductosComparativo con el rango de 6 meses como período A ──
        $odooPromedio = $this->odoo->getProductosComparativo(
            $documento,
            ['desde' => $inicioPromedio->format('Y-m-d'), 'hasta' => $finPromedio->format('Y-m-d')],
            ['desde' => $inicioMesActualStr,               'hasta' => $finMesActualStr]
        );

        $compradoPromedioPorCodigo = collect();
        if ($odooPromedio['encontrado'] ?? false) {
            $compradoPromedioPorCodigo = collect($odooPromedio['productos'])
                ->mapWithKeys(fn($p) => [$p['codigo'] => round(((float) $p['comp_a']) / 6, 1)]);
        }

        // ── Formulado: mismo rango de 6 meses ──
        $formulacionesPromedio = collect($this->odoo->getFormulacionPorDocumento($documento, $inicioPromedio->format('Y-m-d')))
            ->filter(function ($l) use ($inicioPromedio, $finPromedio) {
                $fecha  = Carbon::parse($l['fecha'] ?? now());
                $estado = strtoupper($l['estado'] ?? '');
                return $fecha->between($inicioPromedio, $finPromedio) && !in_array($estado, ['CANCEL', 'CANCELADO', 'CANCELADA']);
            })
            ->groupBy('codigo')
            ->map(fn($grupo) => round(((float) $grupo->sum('cantidad')) / 6, 1));

        // ── Unificamos por código ──
        $codigos = $compradoPromedioPorCodigo->keys()->merge($formulacionesPromedio->keys())->unique();

        $datos = $codigos->mapWithKeys(function ($codigo) use ($compradoPromedioPorCodigo, $formulacionesPromedio) {
            return [$codigo => [
                'comprado_promedio'  => $compradoPromedioPorCodigo->get($codigo, 0),
                'formulado_promedio' => $formulacionesPromedio->get($codigo, 0),
            ]];
        });

        return [
            'datos'      => $datos,
            'rangoLabel' => $rangoPromedioLabel,
        ];
    }

    /**
     * Calcula la variación porcentual entre un valor actual y un promedio.
     * Devuelve null cuando no hay base de comparación (promedio 0 y actual > 0).
     */
    private function calcularVariacionPromedio(float $actual, float $promedio): ?float
    {
        if ($promedio > 0) {
            return round((($actual - $promedio) / $promedio) * 100, 1);
        }
        return $actual > 0 ? null : 0.0;
    }

    /**
     * Reemplaza medico->especialidad (columna local, legado) por la
     * especialidad real resuelta desde el tag del contacto en Odoo,
     * cruzando por documento. Si Odoo no tiene un tag reconocido para
     * ese documento, queda en null.
     */
    private function inyectarEspecialidadOdoo(iterable $medicos): void
    {
        $documentos = collect($medicos)->pluck('documento')->filter()->all();
        $especialidades = $this->odoo->getEspecialidadesPorDocumentos($documentos);

        foreach ($medicos as $medico) {
            $medico->especialidad = $especialidades[trim((string) $medico->documento)] ?? null;
        }
    }

    /**
     * Igual que inyectarEspecialidadOdoo() pero para un único documento.
     */
    private function resolverEspecialidadOdoo(?string $documento): ?string
    {
        if (empty($documento)) return null;

        return $this->odoo->getEspecialidadesPorDocumentos([$documento])[trim($documento)] ?? null;
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'documento'            => 'nullable|string|unique:medicos,documento',
            'nombre'               => 'required|string|max:100',
            'tipo_documento_id'    => 'required|integer',
            'geolocalizacion'      => 'nullable|string|max:300',
            'direccion_detalles'   => 'nullable|string',
            'telefono_contacto'    => 'nullable|string|max:50',
            'horario_atencion'     => 'nullable|string|max:100',
            'visitador_id'         => 'nullable|exists:visitadores,id',
            'fecha_inicio_relacion'=> 'nullable|date',
        ], [
            'required' => 'El campo :attribute es obligatorio.',
            'unique'   => 'Este :attribute ya se encuentra registrado.',
            'string'   => 'El campo :attribute debe ser una cadena de texto.',
            'exists'   => 'El :attribute seleccionado no existe.',
            'date'     => 'La :attribute no tiene un formato válido.',
        ], [
            'documento'         => 'Número de Documento',
            'nombre'            => 'Nombre',

            'tipo_documento_id' => 'Tipo de Documento',
            'visitador_id'      => 'Visitador Asignado',
            'fecha_inicio_relacion' => 'Fecha de Inicio',
        ]);

        Medico::create($validated);

        return Redirect::route('Gmedicos.index')->with('message', 'Médico creado con éxito.');
    }

    /**
     * Actualiza la observación general del médico (perfil), independiente
     * de las observaciones/comentarios que se guardan por cada visita.
     */
    public function actualizarObservaciones(Request $request, Medico $medico)
    {
        $user = $request->user();
        if ($user && $user->id_rol == 2) {
            $visitador = \App\Models\Visitador::where('usuario_id', $user->id)->first();
            if (!$visitador || $medico->visitador_id !== $visitador->id) {
                abort(403, 'No tienes permiso para actualizar las observaciones de este médico.');
            }
        }

        $validated = $request->validate([
            'observaciones' => 'nullable|string',
        ]);

        $medico->update($validated);

        return back()->with('message', 'Observación del médico actualizada.');
    }

    public function update(Request $request, Medico $medico)
    {
        $validated = $request->validate([
            'documento'            => 'required|string|unique:medicos,documento,' . $medico->id,
            'nombre'               => 'required|string|max:100',
            'tipo_documento_id'    => 'required|integer',
            'geolocalizacion'      => 'nullable|string|max:300',
            'direccion_detalles'   => 'nullable|string',
            'telefono_contacto'    => 'nullable|string|max:50',
            'horario_atencion'     => 'nullable|string|max:100',
            'visitador_id'         => 'nullable|exists:visitadores,id',
            'fecha_inicio_relacion'=> 'nullable|date',
        ], [
            'required' => 'El campo :attribute es necesario.',
            'unique'   => 'Este :attribute ya pertenece a otro médico.',
            'string'   => 'El campo :attribute debe ser una cadena de texto.',
        ], [
            'documento'         => 'Número de Documento',
            'nombre'            => 'Nombre',

            'tipo_documento_id' => 'Tipo de Documento',
        ]);

        $medico->update($validated);

        return Redirect::route('Gmedicos.index')->with('message', 'Médico actualizado con éxito.');
    }

    public function destroy(Medico $medico)
    {
        $medico->delete();
        return Redirect::route('Gmedicos.index')->with('message', 'Médico eliminado correctamente.');
    }

    // =========================================================================
    //  EXPORT / IMPORT / MASIVOS — Sin cambios
    // =========================================================================
public function exportar(Request $request)
{
    $idsRaw = $request->input('ids');
    $ids    = $idsRaw ? explode(',', $idsRaw) : [];
    $downloadToken = $request->input('download_token');

    if ($downloadToken) {
        // Asignamos la cookie en texto plano accesible por JavaScript (httpOnly = false)
        $cookie = cookie('download_token', $downloadToken, 1, '/', null, false, false);
        Cookie::queue($cookie);
    }

    return Excel::download(
        new MedicosExport($ids),
        'Medicos_LFH_' . date('d-m-Y') . '.xlsx'
    );
}



    public function importar(Request $request)
    {
        $request->validate([
            'archivo' => 'required|mimes:xlsx,xls,csv'
        ]);

        set_time_limit(300);
        ini_set('memory_limit', '612M');

        try {
            $file      = $request->file('archivo');
            $extension = $file->getClientOriginalExtension();

            $format = match(strtolower($extension)) {
                'csv'  => ExcelFormat::CSV,
                'xlsx' => ExcelFormat::XLSX,
                'xls'  => ExcelFormat::XLS,
                default => ExcelFormat::XLSX,
            };

            Excel::import(new MedicosImport, $file, null, $format);

            return Redirect::route('Gmedicos.index')
                ->with('message', '¡Importación completada!');

        } catch (\Exception $e) {
            Log::error("Error en importación: " . $e->getMessage());
            return Redirect::route('Gmedicos.index')
                ->with('error', 'Error: ' . $e->getMessage());
        }
    }

    public function vincularVisitador(Request $request)
    {
        $request->validate([
            'medico_ids'   => 'required|array',
            'visitador_id' => 'required|exists:visitadores,id',
        ]);

        Medico::whereIn('id', $request->medico_ids)
              ->update(['visitador_id' => $request->visitador_id]);

        return redirect()->back();
    }

    public function eliminarMasivo(Request $request)
    {
        $request->validate([
            'ids' => 'required|array',
        ]);

        $ids = array_filter($request->ids, 'is_numeric');

        set_time_limit(0);

        foreach (array_chunk($ids, 500) as $chunk) {
            Medico::whereIn('id', $chunk)->delete();
        }

        return redirect()->back()->with('message', 'Médicos eliminados con éxito.');
    }

    // =========================================================================
    //  DETALLE DEL MÉDICO — Datos de transacciones desde Odoo
    // =========================================================================
public function show(Request $request, $id)
    {
        $medico = Medico::with(['visitador', 'tipoDocumento', 'categoria'])->findOrFail($id);
        $doc    = $medico->documento;
        $medico->especialidad = $this->resolverEspecialidadOdoo($doc);
        // El tipo de documento se resuelve en vivo contra Odoo (l10n_latam_identification_type_id):
        // el catálogo local puede quedar desactualizado frente al dato real capturado allá.
        $tipoDocumentoOdoo = $this->odoo->getTipoDocumentoPorDocumento($doc);

        $historialCategoria = $this->obtenerHistorialCategoria($medico);
        $medico->categoria_tendencia = $this->calcularTendenciaCategoria($historialCategoria->get(0), $historialCategoria->get(1));

        // ── Período ──────────────────────────────────────────────────────────
        [$periodo, $fechaDesde, $fechaHasta, $fechaDesdeCustom, $fechaHastaCustom] = $this->resolverPeriodo($request);

        // ── Datos Odoo y Formulación Local ────────────────────────────────────
        $odooData = $this->odoo->getKpisPorDocumento($doc, $fechaDesde, $fechaHasta);

        // Obtener la formulación real desde la base de datos local para este período
        $formulacionLocal = $this->odoo->getFormulacionPorDocumento($doc, $fechaDesde, $fechaHasta) ?? [];

        $todosProductosRaw = $odooData['todos_productos'] ?? [];

        // Unificar tendencia mensual: comprado (ya viene de Odoo) + formulado
        // (hay que sumarlo mes a mes, igual que en showPorDocumento).
        $tendenciaMap = [];
        foreach ($odooData['tendencia'] ?? [] as $t) {
            $mes = $t['mes'];
            $tendenciaMap[$mes] = [
                'mes'             => $mes,
                'valor_comprado'  => (float) ($t['valor_comprado'] ?? 0),
                'valor_formulado' => (float) ($t['valor_formulado'] ?? 0),
                'unidades'        => (float) ($t['unidades'] ?? 0),
            ];
        }

        foreach ($formulacionLocal as $linea) {
            $estado = strtoupper($linea['estado'] ?? '');
            if ($estado === 'CANCEL' || $estado === 'CANCELADO' || $estado === 'CANCELADA') {
                continue;
            }

            if (!empty($linea['fecha'])) {
                $mes = substr($linea['fecha'], 0, 7); // Y-m
                if (!isset($tendenciaMap[$mes])) {
                    $tendenciaMap[$mes] = [
                        'mes'             => $mes,
                        'valor_comprado'  => 0.0,
                        'valor_formulado' => 0.0,
                        'unidades'        => 0.0,
                    ];
                }
                $tendenciaMap[$mes]['valor_formulado'] += (float) ($linea['subtotal'] ?? $linea['total'] ?? 0);
            }
        }
        ksort($tendenciaMap);
        $tendencia = array_values($tendenciaMap);

        // 1. Unificar productos comprados y formulados de forma idéntica a "showPorDocumento"
        $productosUnificados = [];
        foreach ($todosProductosRaw as $prod) {
            $clave = (!empty($prod['codigo']) && $prod['codigo'] !== '—') ? $prod['codigo'] : $prod['nombre'];
            $productosUnificados[$clave] = [
                'codigo'              => $prod['codigo'] ?? '—',
                'nombre'              => $prod['nombre'] ?? '',
                'laboratorio'         => $prod['laboratorio'] ?? null,
                'valor_comprado'      => (float) ($prod['valor_comprado'] ?? 0),
                'valor_formulado'     => 0.0,
                'unidades'            => (float) ($prod['unidades'] ?? 0),
                'unidades_formuladas' => 0.0,
                'estado'              => $prod['estado'] ?? $prod['state'] ?? 'draft',
            ];
        }

        foreach ($formulacionLocal as $linea) {
            $estado = strtoupper($linea['estado'] ?? '');
            if ($estado === 'CANCEL' || $estado === 'CANCELADO' || $estado === 'CANCELADA') {
                continue;
            }

            $clave = (!empty($linea['codigo']) && $linea['codigo'] !== '—') ? $linea['codigo'] : $linea['nombre'];

            if (!isset($productosUnificados[$clave])) {
                $productosUnificados[$clave] = [
                    'codigo'              => $linea['codigo'] ?? '—',
                    'nombre'              => $linea['nombre'] ?? '',
                    'laboratorio'         => null,
                    'valor_comprado'      => 0.0,
                    'valor_formulado'     => 0.0,
                    'unidades'            => 0.0,
                    'unidades_formuladas' => 0.0,
                    'estado'              => $linea['estado'] ?? 'draft',
                ];
            }

$productosUnificados[$clave]['valor_formulado'] += (float) ($linea['total'] ?? $linea['subtotal'] ?? 0);
            $productosUnificados[$clave]['unidades_formuladas'] += (float) ($linea['cantidad'] ?? 0);
        }

        // 2. Extraer laboratorios de la DB Local e inyectarlos
        $codigosProductos = collect($productosUnificados)->pluck('codigo')->filter(fn($c) => $c !== '—')->unique()->toArray();
        $laboratoriosLocales = DB::table('productos')
            ->whereIn('codigo', $codigosProductos)
            ->pluck('laboratorio', 'codigo')
            ->toArray();

        $todosProductos = collect($productosUnificados)->map(function($prod) use ($laboratoriosLocales) {
            $prod = (object) $prod;
            $prod->laboratorio = $laboratoriosLocales[$prod->codigo] ?? '—';
            return $prod;
        })->values()->all();

        // 3. Totales reales filtrando cancelados
        $totalValorCompradoReal = collect($todosProductos)
            ->filter(function($prod) {
                $estado = strtoupper($prod->estado ?? '');
                return $estado !== 'CANCEL' && $estado !== 'CANCELADO' && $estado !== 'CANCELADA';
            })
            ->sum('valor_comprado');

        $totalUnidadesCompradasReal = collect($todosProductos)
            ->filter(function($prod) {
                $estado = strtoupper($prod->estado ?? '');
                return $estado !== 'CANCEL' && $estado !== 'CANCELADO' && $estado !== 'CANCELADA';
            })
            ->sum('unidades');

        $totalValorFormuladoReal     = collect($todosProductos)->sum('valor_formulado');
        $totalUnidadesFormuladasReal = collect($todosProductos)->sum('unidades_formuladas');

        // 4. Re-ordenar y obtener Top Productos
        usort($todosProductos, function($a, $b) {
            $valA = $a->valor_comprado + $a->valor_formulado;
            $valB = $b->valor_comprado + $b->valor_formulado;
            return $valB <=> $valA;
        });
        $topProductos = array_slice($todosProductos, 0, 6);

        // 5. Agrupación por laboratorio
        $porLaboratorio = collect($todosProductos)
            ->filter(function($item) {
                return !empty($item->laboratorio) && $item->laboratorio !== '—';
            })
            ->groupBy('laboratorio')
            ->map(function($items, $lab) {
                return [
                    'laboratorio'     => $lab,
                    'valor_comprado'  => (float) $items->sum('valor_comprado'),
                    'valor_formulado' => (float) $items->sum('valor_formulado'),
                    'unidades'        => (int) $items->sum('unidades') + (int) $items->sum('unidades_formuladas'),
                    'total_productos' => (int) $items->unique('codigo')->count(),
                ];
            })
            ->sortByDesc(function($item) {
                return $item['valor_comprado'] + $item['valor_formulado'];
            })
            ->values()
            ->all();

        // 6. Construcción del txStats definitivo
        $txStats = $odooData
            ? (object) [
                'total_transacciones'       => ($odooData['total_transacciones'] ?? 0) + count($formulacionLocal),
                'total_valor_comprado'      => $totalValorCompradoReal,
                'total_valor_formulado'     => $totalValorFormuladoReal,              
                'total_unidades'            => $totalUnidadesCompradasReal + $totalUnidadesFormuladasReal,
                'total_unidades_compradas'  => $totalUnidadesCompradasReal,
                'total_unidades_formuladas' => $totalUnidadesFormuladasReal,
                'total_productos'           => count($todosProductos),
                'meses_activo'              => $odooData['meses_activo'] ?? 0,
            ]
            : $this->txStatsVacios();

        // ── Visitas (DB local) ────────────────────────────────────────────────
        $visitaBase = fn() => DB::table('visitas')
            ->where('medico_id', $id)
            ->when($fechaDesde, fn($q) => $q->where('fecha_programada', '>=', $fechaDesde));

        $visitasStats = $visitaBase()->select(
            DB::raw('COUNT(*) as total'),
            DB::raw("SUM(CASE WHEN estado = 'efectiva'      THEN 1 ELSE 0 END) as efectivas"),
            DB::raw("SUM(CASE WHEN estado = 'programada'    THEN 1 ELSE 0 END) as programadas"),
            DB::raw("SUM(CASE WHEN estado = 'cancelada'     THEN 1 ELSE 0 END) as canceladas"),
            DB::raw("SUM(CASE WHEN estado = 'reprogramada'  THEN 1 ELSE 0 END) as reprogramadas"),
            DB::raw("SUM(CASE WHEN estado = 'No contactado' THEN 1 ELSE 0 END) as no_contactados")
        )->first();

        $visitas = $visitaBase()
            ->leftJoin('visitadores', 'visitas.visitador_id', '=', 'visitadores.id')
            ->select(
                'visitas.id',
                'visitas.estado',
                'visitas.fecha_programada',
                'visitas.fecha_realizada',
                'visitas.comentarios',
                DB::raw("CONCAT(visitadores.nombre, ' ', visitadores.apellido) as nombre_visitador")
            )
            ->orderByDesc('visitas.fecha_programada')
            ->take(50)->get();

        // ✅ CÓDIGO CORREGIDO (Incluye al visitador asignado al médico + historial de visitas)

// 1. Obtener todas las métricas de visitas agrupadas por visitador
$visitasPorVisitador = DB::table('visitas')
    ->where('medico_id', $medico->id)
    ->select(
        'visitador_id',
        DB::raw('COUNT(id) as total_visitas'),
        DB::raw("SUM(CASE WHEN estado = 'efectiva' THEN 1 ELSE 0 END) as efectivas"),
        DB::raw('MAX(fecha_programada) as ultima_visita')
    )
    ->groupBy('visitador_id')
    ->get()
    ->keyBy('visitador_id');

// 2. Obtener los IDs de todos los visitadores relevantes (el asignado actual + los que han realizado visitas)
$visitadorIds = collect([$medico->visitador_id])
    ->concat($visitasPorVisitador->keys())
    ->filter()
    ->unique();

// 3. Mapear la información completa de cada visitador
$visitadoresAsignados = \App\Models\Visitador::whereIn('id', $visitadorIds)
    ->get()
    ->map(function ($v) use ($visitasPorVisitador, $medico) {
        $stats = $visitasPorVisitador->get($v->id);
        return [
            'id'             => $v->id,
            'nombre'         => trim("{$v->nombre} {$v->apellido}"),
            'es_asignado'    => $v->id === $medico->visitador_id, // Identifica si es el visitador actual
            'total_visitas'  => $stats->total_visitas ?? 0,
            'efectivas'      => $stats->efectivas ?? 0,
            'ultima_visita'  => $stats->ultima_visita ?? null,
        ];
    })
    ->values();

        $transacciones = $this->odoo->getTransaccionesPorDocumento($doc, $fechaDesde, $fechaHasta);
        $tarifasSinClasificar = $this->odoo->getTarifasSinClasificarPorDocumento($doc, $fechaDesde, $fechaHasta);


// Consultamos los datos detallados del contacto en Odoo
$partnerOdoo = $this->odoo->buscarMedicoPorDocumento($doc);

if ($partnerOdoo) {
    // Teléfonos
    $medico->telefono = $partnerOdoo['telefono'] ?? null;
    $medico->celular  = $partnerOdoo['celular'] ?? null;

    // Cumpleaños / Fecha de nacimiento
   // Cumpleaños / Fecha de nacimiento (Solo Lectura desde Odoo)
    $medico->mes_nacimiento   = $partnerOdoo['mes_nacimiento'] ?? null;
    $medico->dia_nacimiento   = $partnerOdoo['dia_nacimiento'] ?? null;


}

       return Inertia::render('ADMINISTRADOR/MEDICOS/MedicoDetalle', [
            'medico'               => $medico,
            'tipoDocumentoOdoo'    => $tipoDocumentoOdoo,
            'periodoActivo'        => $periodo,
            'fechaDesdeActiva'     => $fechaDesdeCustom,
            'fechaHastaActiva'     => $fechaHastaCustom,
            'txStats'              => $txStats,
            'tendencia'            => $tendencia,
            'topProductos'         => $topProductos,
            'porLaboratorio'       => $porLaboratorio,
            'todosProductos'       => $todosProductos,
            'transacciones'        => $transacciones,
            'tarifasSinClasificar' => $tarifasSinClasificar,
            'visitasStats'         => $visitasStats,
            'visitas'              => $visitas,
            'visitadoresAsignados' => $visitadoresAsignados,
            'categoriaHistorial'   => $historialCategoria,
        ]);
    }

    

    public function showPorDocumento(Request $request, $documento)
    {
        $medicoReal = Medico::with(['visitador', 'tipoDocumento', 'categoria'])
            ->where('documento', $documento)
            ->first();

        $esTemporal    = $medicoReal === null;
        $medicoIdLocal = $medicoReal?->id;

        if ($medicoReal) {
            $medico = $medicoReal;
        } else {
            $temporal = MedicoTemporal::where('documento', $documento)->first();

            // Sin registro local (ni médico ni temporal): el nombre y el
            // contacto se resuelven directo contra el contacto de Odoo
            // (res.partner) para que el buscador universal de /odoo/medicos
            // no muestre "Sin registrar" para clientes que sí existen en Odoo.
            $nombre  = $temporal->nombre_referencia ?? null;
            $telefono = null;

            if (!$nombre) {
                $partnerOdoo = $this->odoo->buscarMedicoPorDocumento($documento);
                $nombre   = $partnerOdoo['name'] ?? null;
                $telefono = $partnerOdoo['mobile'] ?? $partnerOdoo['phone'] ?? null;
            }

            $medico = (object) [
                'id'                 => $temporal->id ?? null,
                'nombre'             => $nombre ?? 'Sin registrar',
                'documento'          => $documento,
                'especialidad'       => null,
                'tipo_documento'     => null,
                'categoria'          => null,
                'visitador'          => null,
                'telefono_contacto'  => $telefono,
                'horario_atencion'   => null,
                'direccion_detalles' => null,
                'geolocalizacion'    => null,
            ];
        }

        $medico->especialidad = $this->resolverEspecialidadOdoo($documento);
        $tipoDocumentoOdoo = $this->odoo->getTipoDocumentoPorDocumento($documento);

        if ($medicoReal) {
            $historialCategoria = $this->obtenerHistorialCategoria($medicoReal);
            $medico->categoria_tendencia = $this->calcularTendenciaCategoria($historialCategoria->get(0), $historialCategoria->get(1));
        } else {
            $historialCategoria = collect();
            $medico->categoria_tendencia = null;
        }

        [$periodo, $fechaDesde, $fechaHasta, $fechaDesdeCustom, $fechaHastaCustom] = $this->resolverPeriodo($request);

        $odooData = $this->odoo->getKpisPorDocumento($documento, $fechaDesde, $fechaHasta);

        $formulacionOdoo = $this->odoo->getFormulacionPorDocumento($documento, $fechaDesde, $fechaHasta) ?? [];
        $todosProductosRaw = $odooData['todos_productos'] ?? [];

        // 1. Unificar productos comprados y formulados
        $productosUnificados = [];
        foreach ($todosProductosRaw as $prod) {
            $clave = (!empty($prod['codigo']) && $prod['codigo'] !== '—') ? $prod['codigo'] : $prod['nombre'];
            $productosUnificados[$clave] = [
                'codigo'              => $prod['codigo'] ?? '—',
                'nombre'              => $prod['nombre'] ?? '',
                'laboratorio'         => $prod['laboratorio'] ?? null,
                'valor_comprado'      => (float) ($prod['valor_comprado'] ?? 0),
                'valor_formulado'     => 0.0,
                'unidades'            => (float) ($prod['unidades'] ?? 0),
                'unidades_formuladas' => 0.0,
                'estado'              => $prod['estado'] ?? $prod['state'] ?? 'draft',
            ];
        }

        foreach ($formulacionOdoo as $linea) {
            $estado = strtoupper($linea['estado'] ?? '');
            if ($estado === 'CANCEL' || $estado === 'CANCELADO' || $estado === 'CANCELADA') {
                continue;
            }

            $clave = (!empty($linea['codigo']) && $linea['codigo'] !== '—') ? $linea['codigo'] : $linea['nombre'];

            if (!isset($productosUnificados[$clave])) {
                $productosUnificados[$clave] = [
                    'codigo'              => $linea['codigo'] ?? '—',
                    'nombre'              => $linea['nombre'] ?? '',
                    'laboratorio'         => null,
                    'valor_comprado'      => 0.0,
                    'valor_formulado'     => 0.0,
                    'unidades'            => 0.0,
                    'unidades_formuladas' => 0.0,
                    'estado'              => $linea['estado'] ?? 'draft',
                ];
            }

            $productosUnificados[$clave]['valor_formulado'] += (float) ($linea['total'] ?? $linea['subtotal'] ?? 0);
            $productosUnificados[$clave]['unidades_formuladas'] += (float) ($linea['cantidad'] ?? 0);
        }

        $codigosProductos = collect($productosUnificados)->pluck('codigo')->filter(fn($c) => $c !== '—')->unique()->toArray();
        $laboratoriosLocales = DB::table('productos')
            ->whereIn('codigo', $codigosProductos)
            ->pluck('laboratorio', 'codigo')
            ->toArray();

        $todosProductos = collect($productosUnificados)->map(function($prod) use ($laboratoriosLocales) {
            $prod = (object) $prod;
            $prod->laboratorio = $laboratoriosLocales[$prod->codigo] ?? '—';
            return $prod;
        })->values()->all();

        // 2. Calculamos los totales reales
        $totalValorCompradoReal = collect($todosProductos)
            ->filter(function($prod) {
                $estado = strtoupper($prod->estado ?? '');
                return $estado !== 'CANCEL' && $estado !== 'CANCELADO' && $estado !== 'CANCELADA';
            })
            ->sum('valor_comprado');

        $totalUnidadesCompradasReal = collect($todosProductos)
            ->filter(function($prod) {
                $estado = strtoupper($prod->estado ?? '');
                return $estado !== 'CANCEL' && $estado !== 'CANCELADO' && $estado !== 'CANCELADA';
            })
            ->sum('unidades');

        $totalValorFormuladoReal = collect($todosProductos)->sum('valor_formulado');
        $totalUnidadesFormuladasReal = collect($todosProductos)->sum('unidades_formuladas');

        // 3. Unificar tendencia
        $tendenciaMap = [];
        foreach ($odooData['tendencia'] ?? [] as $t) {
            $mes = $t['mes'];
            $tendenciaMap[$mes] = [
                'mes'             => $mes,
                'valor_comprado'  => (float) ($t['valor_comprado'] ?? 0),
                'valor_formulado' => (float) ($t['valor_formulado'] ?? 0),
                'unidades'        => (float) ($t['unidades'] ?? 0),
            ];
        }

        foreach ($formulacionOdoo as $linea) {
            $estado = strtoupper($linea['estado'] ?? '');
            if ($estado === 'CANCEL' || $estado === 'CANCELADO' || $estado === 'CANCELADA') {
                continue;
            }

            if (!empty($linea['fecha'])) {
                $mes = substr($linea['fecha'], 0, 7); // Y-m
                if (!isset($tendenciaMap[$mes])) {
                    $tendenciaMap[$mes] = [
                        'mes'             => $mes,
                        'valor_comprado'  => 0.0,
                        'valor_formulado' => 0.0,
                        'unidades'        => 0.0,
                    ];
                }
                $tendenciaMap[$mes]['valor_formulado'] += (float) ($linea['subtotal'] ?? $linea['total'] ?? 0);
            }
        }
        ksort($tendenciaMap);
        $tendencia = array_values($tendenciaMap);

        // 4. Re-ordenar y obtener Top Productos
        usort($todosProductos, function($a, $b) {
            $valA = $a->valor_comprado + $a->valor_formulado;
            $valB = $b->valor_comprado + $b->valor_formulado;
            return $valB <=> $valA;
        });
        $topProductos = array_slice($todosProductos, 0, 6);

        // 5. Crear objeto $txStats
        $txStats = $odooData
            ? (object) [
                'total_transacciones'       => ($odooData['total_transacciones'] ?? 0) + count($formulacionOdoo),
                'total_valor_comprado'      => $totalValorCompradoReal,
                'total_valor_formulado'     => $totalValorFormuladoReal,
                'total_unidades'            => $totalUnidadesCompradasReal + $totalUnidadesFormuladasReal,
                'total_unidades_compradas'  => $totalUnidadesCompradasReal,
                'total_unidades_formuladas' => $totalUnidadesFormuladasReal,
                'total_productos'           => count($todosProductos),
                'meses_activo'              => count(array_filter($tendencia, fn($m) => $m['valor_comprado'] > 0 || $m['valor_formulado'] > 0)),
            ]
            : $this->txStatsVacios();

        // 6. Agrupación por laboratorio
        $porLaboratorio = collect($todosProductos)
            ->filter(function($item) {
                return !empty($item->laboratorio) && $item->laboratorio !== '—';
            })
            ->groupBy('laboratorio')
            ->map(function($items, $lab) {
                return [
                    'laboratorio'     => $lab,
                    'valor_comprado'  => (float) $items->sum('valor_comprado'),
                    'valor_formulado' => (float) $items->sum('valor_formulado'),
                    'unidades'        => (int) $items->sum('unidades') + (int) $items->sum('unidades_formuladas'),
                    'total_productos' => (int) $items->unique('codigo')->count(),
                ];
            })
            ->sortByDesc(function($item) {
                return $item['valor_comprado'] + $item['valor_formulado'];
            })
            ->values()
            ->all();

        // 5. Carga de visitas locales
        if ($medicoIdLocal) {
            $visitaBase = fn() => DB::table('visitas')
                ->where('medico_id', $medicoIdLocal)
                ->when($fechaDesde, fn($q) => $q->where('fecha_programada', '>=', $fechaDesde));

            $visitasStats = $visitaBase()->select(
                DB::raw('COUNT(*) as total'),
                DB::raw("SUM(CASE WHEN estado = 'efectiva'      THEN 1 ELSE 0 END) as efectivas"),
                DB::raw("SUM(CASE WHEN estado = 'programada'    THEN 1 ELSE 0 END) as programadas"),
                DB::raw("SUM(CASE WHEN estado = 'cancelada'     THEN 1 ELSE 0 END) as canceladas"),
                DB::raw("SUM(CASE WHEN estado = 'reprogramada'  THEN 1 ELSE 0 END) as reprogramadas"),
                DB::raw("SUM(CASE WHEN estado = 'No contactado' THEN 1 ELSE 0 END) as no_contactados")
            )->first();

            $visitas = $visitaBase()
                ->leftJoin('visitadores', 'visitas.visitador_id', '=', 'visitadores.id')
                ->select(
                    'visitas.id',
                    'visitas.estado',
                    'visitas.fecha_programada',
                    'visitas.fecha_realizada',
                    'visitas.comentarios',
                    DB::raw("CONCAT(visitadores.nombre, ' ', visitadores.apellido) as nombre_visitador")
                )
                ->orderByDesc('visitas.fecha_programada')
                ->take(50)->get();

            $visitadoresAsignados = DB::table('visitas')
                ->where('visitas.medico_id', $medicoIdLocal)
                ->join('visitadores', 'visitas.visitador_id', '=', 'visitadores.id')
                ->select(
                    'visitadores.id',
                    DB::raw("CONCAT(visitadores.nombre, ' ', visitadores.apellido) as nombre"),
                    DB::raw('COUNT(visitas.id) as total_visitas'),
                    DB::raw("SUM(CASE WHEN visitas.estado = 'efectiva' THEN 1 ELSE 0 END) as efectivas"),
                    DB::raw('MAX(visitas.fecha_programada) as ultima_visita')
                )
                ->groupBy('visitadores.id', 'visitadores.nombre', 'visitadores.apellido')
                ->orderByDesc('total_visitas')->get();
        } else {
            $visitasStats = (object) [
                'total' => 0, 'efectivas' => 0, 'programadas' => 0,
                'canceladas' => 0, 'reprogramadas' => 0, 'no_contactados' => 0,
            ];
            $visitas = [];
            $visitadoresAsignados = [];
        }

        $transacciones = $this->odoo->getTransaccionesPorDocumento($documento, $fechaDesde, $fechaHasta);
        $tarifasSinClasificar = $this->odoo->getTarifasSinClasificarPorDocumento($documento, $fechaDesde, $fechaHasta);

        return Inertia::render('ADMINISTRADOR/MEDICOS/MedicoDetalle', [
            'medico'               => $medico,
            'tipoDocumentoOdoo'    => $tipoDocumentoOdoo,
            'periodoActivo'        => $periodo,
            'fechaDesdeActiva'     => $fechaDesdeCustom,
            'fechaHastaActiva'     => $fechaHastaCustom,
            'txStats'              => $txStats,
            'tendencia'            => $tendencia,
            'topProductos'         => $topProductos,
            'porLaboratorio'       => $porLaboratorio,
            'todosProductos'       => $todosProductos,
            'transacciones'        => $transacciones,
            'tarifasSinClasificar' => $tarifasSinClasificar,
            'visitasStats'         => $visitasStats,
            'visitas'              => $visitas,
            'visitadoresAsignados' => $visitadoresAsignados,
            'odooConectado'        => $odooData !== null,
            'esTemporal'           => $esTemporal,
            'documentoBase'        => $documento,
            'categoriaHistorial'   => $historialCategoria,
        ]);
    }

    // =========================================================================
    //  SINCRONIZACIÓN PUNTUAL — historial de categoría de UN médico
    // =========================================================================

    /**
     * Botón "Sincronizar" del panel de detalle: refresca TODOS los datos que
     * el panel consulta en Odoo para este médico puntual (KPIs, tendencia,
     * productos, transacciones, cartera, especialidad, tipo de documento...).
     * Esos datos se cachean 30 min por documento+rango (OdooService::
     * cacheKeyPorDocumento) para no golpear Odoo en cada carga del panel;
     * aquí se invalida esa caché primero (invalidarCachePorDocumento) para
     * que la recarga que sigue traiga datos frescos y no la copia cacheada.
     * Además queda persistido el historial de categoría (últimos 12 meses
     * cerrados), porque a diferencia del resto es un snapshot histórico, no
     * un dato "en vivo": se guarda en `medico_categoria_historial`, igual que
     * hace el comando programado `medicos:calcular-categorias`, pero para
     * todos los médicos por lote. Al terminar, back() vuelve a la misma URL
     * (con su período activo) y esa recarga trae los datos ya frescos.
     */
    public function sincronizarCategoriaPorDocumento(Request $request, $documento)
    {
        // Limpia todo lo cacheado en OdooService para este documento (KPIs,
        // transacciones, formulación, tarifas, tipo de documento) para
        // cualquier rango de fechas, así la recarga que sigue trae datos
        // frescos en vez de la copia de hasta 30 min que pudiera existir.
        $this->odoo->invalidarCachePorDocumento($documento);

        $medico = Medico::where('documento', $documento)->first();

        if (!$medico) {
            return back()->with('error', 'Este documento no está registrado localmente como médico; no se puede guardar su historial de categoría.');
        }

        $mesActualInicio = Carbon::now()->startOfMonth();
        // Últimos 12 meses CERRADOS (no se recalcula el mes en curso, igual
        // que el comando programado, para no guardar un snapshot parcial).
        $fechaHasta = $mesActualInicio->copy()->subDay()->endOfMonth()->format('Y-m-d');
        $fechaDesde = $mesActualInicio->copy()->subMonthsNoOverflow(12)->format('Y-m-d');

        $odooData    = $this->odoo->getKpisPorDocumento($documento, $fechaDesde, $fechaHasta);
        $formulacion = $this->odoo->getFormulacionPorDocumento($documento, $fechaDesde, $fechaHasta) ?? [];

        $mensual = [];
        foreach ($odooData['tendencia'] ?? [] as $t) {
            $mensual[$t['mes']] = [
                'comprado'  => (float) ($t['valor_comprado'] ?? 0),
                'formulado' => 0.0,
            ];
        }
        foreach ($formulacion as $linea) {
            $estado = strtoupper($linea['estado'] ?? '');
            if (in_array($estado, ['CANCEL', 'CANCELADO', 'CANCELADA'], true)) continue;
            if (empty($linea['fecha'])) continue;

            $mes = substr($linea['fecha'], 0, 7);
            $mensual[$mes] ??= ['comprado' => 0.0, 'formulado' => 0.0];
            $mensual[$mes]['formulado'] += (float) ($linea['subtotal'] ?? $linea['total'] ?? 0);
        }

        if (empty($mensual)) {
            return back()->with('error', 'No se encontraron datos en Odoo para este médico en los últimos 12 meses.');
        }

        $categorias = Categoria::orderByDesc('valor_minimo')->get();
        $mesMasReciente = null;
        $categoriaMasReciente = null;
        $actualizados = 0;

        foreach ($mensual as $mes => $valores) {
            $valorTotal = $valores['comprado'] + $valores['formulado'];
            $categoria  = $categorias->first(fn($c) => (float) $c->valor_minimo <= $valorTotal);

            MedicoCategoriaHistorial::updateOrCreate(
                ['medico_id' => $medico->id, 'mes' => $mes . '-01'],
                [
                    'categoria_id'    => $categoria?->id,
                    'valor_comprado'  => $valores['comprado'],
                    'valor_formulado' => $valores['formulado'],
                    'valor_total'     => $valorTotal,
                ]
            );
            $actualizados++;

            if (!$mesMasReciente || $mes > $mesMasReciente) {
                $mesMasReciente       = $mes;
                $categoriaMasReciente = $categoria;
            }
        }

        $medico->update(['categoria_id' => $categoriaMasReciente?->id]);

        return back()->with('success', "Datos de Odoo sincronizados para este médico ({$actualizados} mes(es) de categoría actualizados).");
    }

    // =========================================================================
    //  ALERTAS DE PRODUCTOS — Comparativo desde Odoo
    // =========================================================================

   // =========================================================================
    //  ALERTAS DE PRODUCTOS — Comparativo desde Odoo
    // =========================================================================

    public function alertasProductos(Request $request, $id)
    {
        $medico = Medico::with(['visitador', 'tipoDocumento', 'categoria'])->findOrFail($id);
        $doc    = $medico->documento;

        // ── Mes actual (fijo: hoy) ────────────────────────────────────────────
        $hoyReal         = Carbon::now();
        $inicioMesActual = $hoyReal->copy()->startOfMonth()->format('Y-m-d');
        $finMesActual    = $hoyReal->copy()->endOfMonth()->format('Y-m-d');
        $mesActualLabel  = ucfirst($hoyReal->locale('es')->isoFormat('MMMM YYYY'));

        // ── Mes seleccionado (dinámico) ───────────────────────────────────────
        $mesQuery = $request->input('mes', Carbon::now()->subMonth()->format('Y-m'));

        try {
            $mesSeleccionado = Carbon::createFromFormat('Y-m', $mesQuery);
        } catch (\Exception $e) {
            $mesSeleccionado = Carbon::now()->subMonth();
            $mesQuery        = $mesSeleccionado->format('Y-m');
        }

        $inicioMesSeleccionado = $mesSeleccionado->copy()->startOfMonth()->format('Y-m-d');
        $finMesSeleccionado    = $mesSeleccionado->copy()->endOfMonth()->format('Y-m-d');
        $mesSeleccionadoLabel  = ucfirst($mesSeleccionado->locale('es')->isoFormat('MMMM YYYY'));

        // ── Promedio últimos 6 meses (opcional, no reemplaza el selector de mes) ──
        $incluirPromedio  = $request->boolean('promedio', false);
        $rangoPromedioLabel = null;
        $promedioPorCodigo = collect();

        if ($incluirPromedio) {
            $promedioCalculo    = $this->calcularPromedioSeisMeses($doc, $hoyReal, $inicioMesActual, $finMesActual);
            $promedioPorCodigo  = $promedioCalculo['datos'];
            $rangoPromedioLabel = $promedioCalculo['rangoLabel'];
        }

        // ── Consulta comparativa a Odoo ───────────────────────────────────────
        $odooResult = $this->odoo->getProductosComparativo(
            $doc,
            ['desde' => $inicioMesSeleccionado, 'hasta' => $finMesSeleccionado],
            ['desde' => $inicioMesActual,        'hasta' => $finMesActual]
        );

        if (!$odooResult['encontrado']) {
            Log::warning('[Medico2Controller] alertasProductos: ' . ($odooResult['mensaje'] ?? 'Sin datos Odoo'));
            $productosAlertas = [];
        } else {
            // ── OBTENER Y FILTRAR FORMULACIONES PARA AMBOS PERÍODOS ──
            $formulacionesMesSeleccionado = collect($this->odoo->getFormulacionPorDocumento($doc, $inicioMesSeleccionado))
                ->filter(function($l) use ($inicioMesSeleccionado, $finMesSeleccionado) {
                    $fecha = Carbon::parse($l['fecha'] ?? now());
                    $estado = strtoupper($l['estado'] ?? '');
                    return $fecha->between($inicioMesSeleccionado, $finMesSeleccionado) && !in_array($estado, ['CANCEL', 'CANCELADO', 'CANCELADA']);
                })->groupBy('codigo');

            $formulacionesMesActual = collect($this->odoo->getFormulacionPorDocumento($doc, $inicioMesActual))
                ->filter(function($l) use ($inicioMesActual, $finMesActual) {
                    $fecha = Carbon::parse($l['fecha'] ?? now());
                    $estado = strtoupper($l['estado'] ?? '');
                    return $fecha->between($inicioMesActual, $finMesActual) && !in_array($estado, ['CANCEL', 'CANCELADO', 'CANCELADA']);
                })->groupBy('codigo');

            // Mapeamos e inyectamos los datos reales cruzados por código
            $productosAlertas = collect($odooResult['productos'])->map(function ($p) use ($formulacionesMesSeleccionado, $formulacionesMesActual, $promedioPorCodigo, $incluirPromedio) {
                $codigo = $p['codigo'];

                $cantFormSeleccionado = $formulacionesMesSeleccionado->has($codigo) ? (int)$formulacionesMesSeleccionado->get($codigo)->sum('cantidad') : 0;
                $cantFormActual       = $formulacionesMesActual->has($codigo) ? (int)$formulacionesMesActual->get($codigo)->sum('cantidad') : 0;
                $diffFormulado        = $cantFormActual - $cantFormSeleccionado;
                
                $tendenciaFormulado = 'igual';
                if ($diffFormulado > 0) $tendenciaFormulado = 'subio';
                if ($diffFormulado < 0) $tendenciaFormulado = 'bajo';

                $fila = [
                    'codigo'                     => $codigo,
                    'nombre'                     => $p['nombre'],
                    'laboratorio'                => $p['laboratorio'] ?? '—',

                    // Período A = mes seleccionado histórico (Inyección Real)
                    'formulado_mes_seleccionado' => $cantFormSeleccionado,
                    'comprado_mes_seleccionado'  => (int) $p['comp_a'],

                    // Período B = mes actual (Inyección Real)
                    'formulado_mes_actual'       => $cantFormActual,
                    'comprado_mes_actual'        => (int) $p['comp_b'],

                    // Tendencias calculadas
                    'formulado_diferencia'       => $diffFormulado,
                    'formulado_tendencia'        => $tendenciaFormulado,
                    'comprado_diferencia'        => (int) $p['diferencia'],
                    'comprado_tendencia'         => $p['tendencia'],
                ];

                if ($incluirPromedio) {
                    $promedio = $promedioPorCodigo->get($codigo, ['comprado_promedio' => 0, 'formulado_promedio' => 0]);

                    $fila['comprado_promedio_6m']   = $promedio['comprado_promedio'];
                    $fila['comprado_variacion_pct']  = $this->calcularVariacionPromedio((float) $p['comp_b'], (float) $promedio['comprado_promedio']);

                    $fila['formulado_promedio_6m']  = $promedio['formulado_promedio'];
                    $fila['formulado_variacion_pct'] = $this->calcularVariacionPromedio((float) $cantFormActual, (float) $promedio['formulado_promedio']);
                }

                return $fila;
            })->all();
        }

        $puestoReal = $this->esCategoriaTope($medico->categoria_id) ? 1 : null;

        return Inertia::render('ADMINISTRADOR/MEDICOS/ProductosAlertaAdmin', [
            'medico'               => $medico,
            'productosAlertas'     => $productosAlertas,
            'mesActualLabel'       => $mesActualLabel,
            'mesSeleccionadoLabel' => $mesSeleccionadoLabel,
            'mesQuery'             => $mesQuery,
            'puestoReal'           => $puestoReal,
            'odooConectado'        => $odooResult['encontrado'],
            'incluirPromedio'      => $incluirPromedio,
            'rangoPromedioLabel'   => $rangoPromedioLabel,
        ]);
    }

    public function alertasPorDocumento(Request $request, $documento)
    {
        $medicoReal = Medico::with(['visitador', 'tipoDocumento', 'categoria'])
            ->where('documento', $documento)
            ->first();

        if ($medicoReal) {
            $medico = $medicoReal;
        } else {
            $temporal = MedicoTemporal::where('documento', $documento)->first();

            $medico = (object) [
                'id'           => $temporal->id ?? null,
                'nombre'       => $temporal->nombre_referencia ?? 'Sin registrar',
                'documento'    => $documento,
                'categoria_id' => null,
            ];
        }

        $hoyReal         = Carbon::now();
        $inicioMesActual = $hoyReal->copy()->startOfMonth()->format('Y-m-d');
        $finMesActual    = $hoyReal->copy()->endOfMonth()->format('Y-m-d');
        $mesActualLabel  = ucfirst($hoyReal->locale('es')->isoFormat('MMMM YYYY'));

        $mesQuery = $request->input('mes', Carbon::now()->subMonth()->format('Y-m'));

        try {
            $mesSeleccionado = Carbon::createFromFormat('Y-m', $mesQuery);
        } catch (\Exception $e) {
            $mesSeleccionado = Carbon::now()->subMonth();
            $mesQuery        = $mesSeleccionado->format('Y-m');
        }

        $inicioMesSeleccionado = $mesSeleccionado->copy()->startOfMonth()->format('Y-m-d');
        $finMesSeleccionado    = $mesSeleccionado->copy()->endOfMonth()->format('Y-m-d');
        $mesSeleccionadoLabel  = ucfirst($mesSeleccionado->locale('es')->isoFormat('MMMM YYYY'));

        // ── Promedio últimos 6 meses (opcional, no reemplaza el selector de mes) ──
        $incluirPromedio    = $request->boolean('promedio', false);
        $rangoPromedioLabel = null;
        $promedioPorCodigo  = collect();

        if ($incluirPromedio) {
            $promedioCalculo    = $this->calcularPromedioSeisMeses($documento, $hoyReal, $inicioMesActual, $finMesActual);
            $promedioPorCodigo  = $promedioCalculo['datos'];
            $rangoPromedioLabel = $promedioCalculo['rangoLabel'];
        }

        $odooResult = $this->odoo->getProductosComparativo(
            $documento,
            ['desde' => $inicioMesSeleccionado, 'hasta' => $finMesSeleccionado],
            ['desde' => $inicioMesActual,        'hasta' => $finMesActual]
        );

        if (!$odooResult['encontrado']) {
            Log::warning('[Medico2Controller] alertasPorDocumento: ' . ($odooResult['mensaje'] ?? 'Sin datos Odoo'));
            $productosAlertas = [];
        } else {
            // ── OBTENER Y FILTRAR FORMULACIONES PARA AMBOS PERÍODOS ──
            $formulacionesMesSeleccionado = collect($this->odoo->getFormulacionPorDocumento($documento, $inicioMesSeleccionado))
                ->filter(function($l) use ($inicioMesSeleccionado, $finMesSeleccionado) {
                    $fecha = Carbon::parse($l['fecha'] ?? now());
                    $estado = strtoupper($l['estado'] ?? '');
                    return $fecha->between($inicioMesSeleccionado, $finMesSeleccionado) && !in_array($estado, ['CANCEL', 'CANCELADO', 'CANCELADA']);
                })->groupBy('codigo');

            $formulacionesMesActual = collect($this->odoo->getFormulacionPorDocumento($documento, $inicioMesActual))
                ->filter(function($l) use ($inicioMesActual, $finMesActual) {
                    $fecha = Carbon::parse($l['fecha'] ?? now());
                    $estado = strtoupper($l['estado'] ?? '');
                    return $fecha->between($inicioMesActual, $finMesActual) && !in_array($estado, ['CANCEL', 'CANCELADO', 'CANCELADA']);
                })->groupBy('codigo');

            // Mapeamos e inyectamos los datos reales cruzados por código
            $productosAlertas = collect($odooResult['productos'])->map(function ($p) use ($formulacionesMesSeleccionado, $formulacionesMesActual, $promedioPorCodigo, $incluirPromedio) {
                $codigo = $p['codigo'];

                $cantFormSeleccionado = $formulacionesMesSeleccionado->has($codigo) ? (int)$formulacionesMesSeleccionado->get($codigo)->sum('cantidad') : 0;
                $cantFormActual       = $formulacionesMesActual->has($codigo) ? (int)$formulacionesMesActual->get($codigo)->sum('cantidad') : 0;
                $diffFormulado        = $cantFormActual - $cantFormSeleccionado;
                
                $tendenciaFormulado = 'igual';
                if ($diffFormulado > 0) $tendenciaFormulado = 'subio';
                if ($diffFormulado < 0) $tendenciaFormulado = 'bajo';

                $fila = [
                    'codigo'                     => $codigo,
                    'nombre'                     => $p['nombre'],
                    'laboratorio'                => $p['laboratorio'] ?? '—',
                    
                    // Período A = mes seleccionado histórico (Inyección Real)
                    'formulado_mes_seleccionado' => $cantFormSeleccionado,
                    'comprado_mes_seleccionado'  => (int) $p['comp_a'],
                    
                    // Período B = mes actual (Inyección Real)
                    'formulado_mes_actual'       => $cantFormActual,
                    'comprado_mes_actual'        => (int) $p['comp_b'],
                    
                    // Tendencias calculadas
                    'formulado_diferencia'       => $diffFormulado,
                    'formulado_tendencia'        => $tendenciaFormulado,
                    'comprado_diferencia'        => (int) $p['diferencia'],
                    'comprado_tendencia'         => $p['tendencia'],
                ];

                if ($incluirPromedio) {
                    $promedio = $promedioPorCodigo->get($codigo, ['comprado_promedio' => 0, 'formulado_promedio' => 0]);

                    $fila['comprado_promedio_6m']    = $promedio['comprado_promedio'];
                    $fila['comprado_variacion_pct']  = $this->calcularVariacionPromedio((float) $p['comp_b'], (float) $promedio['comprado_promedio']);

                    $fila['formulado_promedio_6m']   = $promedio['formulado_promedio'];
                    $fila['formulado_variacion_pct'] = $this->calcularVariacionPromedio((float) $cantFormActual, (float) $promedio['formulado_promedio']);
                }

                return $fila;
            })->all();
        }

        $puestoReal = $this->esCategoriaTope($medico->categoria_id ?? null) ? 1 : null;

        return Inertia::render('ADMINISTRADOR/MEDICOS/ProductosAlertaAdmin', [
            'medico'               => $medico,
            'productosAlertas'     => $productosAlertas,
            'mesActualLabel'       => $mesActualLabel,
            'mesSeleccionadoLabel' => $mesSeleccionadoLabel,
            'mesQuery'             => $mesQuery,
            'puestoReal'           => $puestoReal,
            'odooConectado'        => $odooResult['encontrado'],
            'documentoBase'        => $documento,
            'incluirPromedio'      => $incluirPromedio,
            'rangoPromedioLabel'   => $rangoPromedioLabel,
        ]);
    }

    /**
     * Resuelve el período seleccionado en la vista de detalle de médico.
     * Retorna [periodo, fechaDesde, fechaHasta, fechaDesdeCustom, fechaHastaCustom].
     * fechaDesdeCustom/fechaHastaCustom solo se llenan cuando periodo === 'custom'
     * (se usan para prellenar el calendario en el frontend).
     */
    private function resolverPeriodo(Request $request): array
    {
        // Por defecto "Mes Actual": evita traer el historial completo de
        // Odoo (mucho más lento) en cada carga del panel — el usuario elige
        // "Todo" o un rango personalizado solo cuando lo necesita.
        $periodo = $request->input('periodo', 'mes');
        $fechaDesdeCustom = null;
        $fechaHastaCustom = null;

        if ($periodo === 'custom') {
            $fechaDesdeCustom = $request->input('fecha_desde');
            $fechaHastaCustom = $request->input('fecha_hasta');

            // Sin ambas fechas no hay rango válido: caemos a "Todo" en vez de romper.
            if (!$fechaDesdeCustom || !$fechaHastaCustom) {
                $periodo = 'all';
                $fechaDesdeCustom = null;
                $fechaHastaCustom = null;
            }
        }

        $fechaDesde = $fechaDesdeCustom ?? match ($periodo) {
            'mes'   => Carbon::now()->startOfMonth()->format('Y-m-d'),
            default => null, // 'all'
        };
        $fechaHasta = $fechaHastaCustom;

        return [$periodo, $fechaDesde, $fechaHasta, $fechaDesdeCustom, $fechaHastaCustom];
    }

    /**
     * Estructura de txStats cuando no hay conexión con Odoo.
     */
    private function txStatsVacios(): object
    {
        return (object) [
            'total_transacciones'       => 0,
            'total_valor_comprado'      => 0,
            'total_valor_formulado'     => 0,
            'total_unidades'            => 0,
            'total_unidades_compradas'  => 0,
            'total_unidades_formuladas' => 0,
            'total_productos'           => 0,
            'meses_activo'              => 0,
        ];
    }
}