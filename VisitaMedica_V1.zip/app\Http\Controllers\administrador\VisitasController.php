<?php

namespace App\Http\Controllers\administrador;

use App\Http\Controllers\Controller;
use App\Models\Visita;
use App\Models\Medico;
use App\Models\Visitador;
use Illuminate\Http\Request;
use Inertia\Inertia;
use App\Models\Productos;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Validation\Rule;

class VisitasController extends Controller
{
    /**
     * Muestra la lista de visitas.
     */
public function index()
{
    return Inertia::render('ADMINISTRADOR/VISITAS/Gvisitas', [
        'visitas' => Visita::select(
            'id', 
            'visitador_id', 
            'medico_id', 
            'fecha_programada', 
            'fecha_realizada', 
            'estado', 
            'comentarios', 
            'muestras', 
            'comentario_muestra'
        )
        ->with([
    'medico:id,nombre,documento,direccion_detalles,geolocalizacion', 
    'visitador:id,nombre'
])
        ->orderBy('id', 'desc')
        ->get(),

        // 'medicos' ya NO se carga completo aquí (son 5000+ registros).
        // Se obtiene bajo demanda vía medicosPorVisitador() cuando el
        // usuario elige un visitador en el modal de crear/editar visita.

        'visitadores' => Visitador::select('id', 'nombre')->get(),

        'productos' => Productos::select('id', 'codigo', 'nombre')
            ->orderBy('nombre', 'asc')
            ->get(),
    ]);
}

/**
 * Devuelve los médicos de un visitador específico (carga bajo demanda).
 * Usada por el modal de crear/editar visita para no traer los 5000+
 * médicos completos en cada carga de /Gvisitas.
 */
public function medicosPorVisitador($visitadorId)
{
    $medicos = Medico::where('visitador_id', $visitadorId)
        ->select(
            'id',
            'nombre',
            'documento',
            'visitador_id',
            'direccion_detalles',
            'geolocalizacion'
        )
        ->orderBy('nombre', 'asc')
        ->get();

    return response()->json($medicos);
}

    /**
     * Almacena una nueva visita con validación de relación y disponibilidad.
     */
    public function store(Request $request)
    {
        // 1. Validaciones básicas de Laravel
        $validated = $request->validate([
            'visitador_id'       => 'required|exists:visitadores,id',
            'medico_id'          => [
                'required',
                Rule::exists('medicos', 'id')->where(function ($query) use ($request) {
                    $query->where('visitador_id', $request->visitador_id);
                }),
            ],
            'fecha_programada'   => 'required|date',
            'fecha_realizada'    => 'nullable|date',
            'estado'             => 'required|in:sin programar,programada,efectiva,No contactado,reprogramada,cancelada',
            'comentarios'        => 'nullable|string',
            'muestras'           => 'nullable|string',
            'comentario_muestra' => 'nullable|string',
        ]);

        // 2. Validación de Disponibilidad (Se mantiene para evitar choques exactos)
        $existeCruce = Visita::where('fecha_programada', $request->fecha_programada)
            ->where(function($query) use ($request) {
                $query->where('visitador_id', $request->visitador_id)
                      ->orWhere('medico_id', $request->medico_id);
            })
            ->exists();

        if ($existeCruce) {
            return back()->withErrors([
                'fecha_programada' => 'El visitador o el médico ya tienen una cita programada para este momento.'
            ])->withInput();
        }

        // 3. Crear la visita
        Visita::create($validated);

        return Redirect::route('Gvisitas.index')->with('success', 'Visita creada correctamente.');
    }

    /**
     * Actualiza una visita existente con validación de disponibilidad.
     */
    public function update(Request $request, $id)
    {
        $visita = Visita::findOrFail($id);

        $validated = $request->validate([
            'visitador_id'       => 'required|exists:visitadores,id',
            'medico_id'          => [
                'required',
                Rule::exists('medicos', 'id')->where(function ($query) use ($request) {
                    $query->where('visitador_id', $request->visitador_id);
                }),
            ],
            'fecha_programada'   => 'required|date',
            'fecha_realizada'    => 'nullable|date',
            'estado'             => 'required|in:sin programar,programada,efectiva,No contactado,reprogramada,cancelada',
            'comentarios'        => 'nullable|string',
            'muestras'           => 'nullable|string',
            'comentario_muestra' => 'nullable|string',
        ]);

        // Validación de Disponibilidad (Excluyendo la visita actual)
        $existeCruce = Visita::where('id', '!=', $id)
            ->where('fecha_programada', $request->fecha_programada)
            ->where(function($query) use ($request) {
                $query->where('visitador_id', $request->visitador_id)
                      ->orWhere('medico_id', $request->medico_id);
            })
            ->exists();

        if ($existeCruce) {
            return back()->withErrors([
                'fecha_programada' => 'Esta fecha y hora ya están ocupadas.'
            ]);
        }

        $visita->update($validated);

        return Redirect::route('Gvisitas.index')->with('success', 'Visita actualizada correctamente.');
    }

    /**
     * Elimina una visita.
     */
    public function destroy($id)
    {
        $visita = Visita::findOrFail($id);
        $visita->delete();

        return Redirect::route('Gvisitas.index')->with('success', 'Visita eliminada correctamente.');
    }

    public function destroyBulk(Request $request)
    {
        $request->validate(['ids' => 'required|array', 'ids.*' => 'integer|exists:visitas,id']);
        Visita::whereIn('id', $request->ids)->delete();

        return Redirect::route('Gvisitas.index')->with('success', 'Visitas eliminadas correctamente.');
    }
}