import React, { useState, useRef } from 'react';
import { Head, Link, router } from '@inertiajs/react';
import PanelAdmin from '../PanelAdmin';
import {
    AreaChart, Area, PieChart, Pie, Cell,
    XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';
import {
    FaArrowLeft, FaUserDoctor, FaCalendarCheck,
    FaBoxOpen, FaFileInvoiceDollar, FaPhone, FaClock, FaLocationDot, FaFlask,
    FaCalendarDays, FaXmark, FaArrowTrendUp, FaArrowTrendDown, FaMinus, FaReceipt,
    FaTriangleExclamation, FaRotate, FaSpinner, FaCheck,FaCommentDots,FaMobileScreen,
} from 'react-icons/fa6';
import BarraComparativa, { COLOR_COMPRADO, COLOR_FORMULADO, LeyendaCompradoFormulado } from '@/Components/BarraComparativa';

function TendenciaCategoria({ tendencia }) {
    if (tendencia === 'subio') return <FaArrowTrendUp className="text-emerald-500 text-[10px]" title="Subió de categoría" />;
    if (tendencia === 'bajo') return <FaArrowTrendDown className="text-rose-500 text-[10px]" title="Bajó de categoría" />;
    if (tendencia === 'igual') return <FaMinus className="text-slate-300 text-[8px]" title="Se mantuvo" />;
    return null;
}

// Compara dos snapshots consecutivos de categoriaHistorial por valor_minimo.
function tendenciaEntre(anterior, actual) {
    if (!anterior || !actual) return null;
    const vAnterior = parseFloat(anterior?.categoria?.valor_minimo);
    const vActual   = parseFloat(actual?.categoria?.valor_minimo);
    if (Number.isNaN(vAnterior) || Number.isNaN(vActual)) return null;
    if (vActual > vAnterior) return 'subio';
    if (vActual < vAnterior) return 'bajo';
    return 'igual';
}

const CATEGORIA_TIER_COLORS = ['#f59e0b', '#4184F0', '#8b5cf6', '#10b981', '#94a3b8'];

// Asigna un color por nivel de categoría (mayor valor_minimo = primero en la paleta),
// relativo a las categorías que aparecen en el historial de este médico.
function colorPorNivelCategoria(historial) {
    const valores = [...new Set(
        historial.map(h => parseFloat(h.categoria?.valor_minimo)).filter(v => !Number.isNaN(v))
    )].sort((a, b) => b - a);
    const mapa = new Map();
    valores.forEach((v, i) => mapa.set(v, CATEGORIA_TIER_COLORS[i % CATEGORIA_TIER_COLORS.length]));
    return mapa;
}

// ── helpers ───────────────────────────────────────────────────────────────────
const fmt  = n => new Intl.NumberFormat('es-CO').format(Math.round(n ?? 0));
// Valor completo en pesos, sin abreviar a K/M/B.
const fmtM = n => new Intl.NumberFormat('es-CO', {
    style: 'currency', currency: 'COP', maximumFractionDigits: 0,
}).format(n ?? 0);

const ESTADO_COLOR = {
    efectiva:        '#10b981',
    programada:      '#4184F0',
    reprogramada:    '#f59e0b',
    cancelada:       '#ef4444',
    'No contactado': '#94a3b8',
};
const ESTADO_LABEL = {
    efectiva: 'Efectiva', programada: 'Programada', reprogramada: 'Reprogramada',
    cancelada: 'Cancelada', 'No contactado': 'No contactado',
};
const PROD_COLORS = ['#3D3FD8', '#4184F0', '#06b6d4', '#10b981', '#f59e0b', '#8b5cf6'];



const MESES_NOMBRES = {
    // Si desde Odoo/DB te llega como abreviatura
    ene: 'Enero', feb: 'Febrero', mar: 'Marzo', abr: 'Abril',
    may: 'Mayo', jun: 'Junio', jul: 'Julio', ago: 'Agosto',
    sep: 'Septiembre', oct: 'Octubre', nov: 'Noviembre', dic: 'Diciembre',
    
    // Si también te llega como número (por si acaso)
    1: 'Enero', 2: 'Febrero', 3: 'Marzo', 4: 'Abril',
    5: 'Mayo', 6: 'Junio', 7: 'Julio', 8: 'Agosto',
    9: 'Septiembre', 10: 'Octubre', 11: 'Noviembre', 12: 'Diciembre',
    '01': 'Enero', '02': 'Febrero', '03': 'Marzo', '04': 'Abril',
    '05': 'Mayo', '06': 'Junio', '07': 'Julio', '08': 'Agosto',
    '09': 'Septiembre',
};

// Helper para obtener el mes completo limpiando espacios y minúsculas
function formatoMesCompleto(mes) {
    if (!mes) return '—';
    const mesLimpio = String(mes).trim().toLowerCase();
    return MESES_NOMBRES[mesLimpio] ?? mes; // Si no lo encuentra, muestra el valor original
}

// ── subcomponents ─────────────────────────────────────────────────────────────
function KpiCard({ label, value, accent, href }) {
    const inner = (
        <div className="flex-1 min-w-0 pt-2 pb-4 flex flex-col justify-between h-full relative group">
            {/* Línea/Borde superior colorido */}
            <div 
                className="w-full h-1 rounded-full mb-4" 
                style={{ backgroundColor: accent }} 
            />

            {/* Etiqueta / Título en mayúsculas */}
            <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1 leading-tight">
                {label}
            </p>

            {/* Valor principal */}
            <p className="text-[20px] font-bold text-slate-900 leading-none tracking-tight">
                {value}
            </p>
        </div>
    );

    return href ? (
        <Link href={href} className="flex-1 min-w-0 block h-full transition-opacity hover:opacity-85">
            {inner}
        </Link>
    ) : inner;
}

function EstadoBadge({ estado }) {
    const color = ESTADO_COLOR[estado] ?? '#94a3b8';
    return (
        <span className="inline-block text-[8px] font-black uppercase px-2 py-0.5 rounded-full border"
              style={{ color, background: `${color}18`, borderColor: `${color}40` }}>
            {ESTADO_LABEL[estado] ?? estado}
        </span>
    );
}

function KpiSkeleton({ accent }) {
    return (
        <div className="flex-1 min-w-0 bg-white px-4 py-4 animate-pulse"
             style={{ borderTopColor: accent, borderTopWidth: 4 }}>
            <div className="h-2 w-16 bg-slate-100 rounded mb-3" />
            <div className="h-5 w-20 bg-slate-200 rounded" />
        </div>
    );
}

function ChartSkeleton({ height = 320 }) {
    return (
        <div className="animate-pulse flex flex-col justify-end gap-2" style={{ height }}>
            <div className="flex-1 bg-slate-100 rounded-md" />
            <div className="h-2 w-1/2 bg-slate-100 rounded mx-auto" />
        </div>
    );
}

function BarRowSkeleton() {
    return (
        <div className="animate-pulse">
            <div className="flex justify-between mb-1.5">
                <div className="h-2 w-24 bg-slate-100 rounded" />
                <div className="h-2 w-12 bg-slate-100 rounded" />
            </div>
            <div className="w-full h-1.5 bg-slate-100 rounded-full" />
        </div>
    );
}

function OdooStatusBadge({ loading, error }) {
    if (loading) {
        return (
            <span className="inline-flex items-center gap-1.5 text-[8px] font-black uppercase px-2.5 py-1 rounded-full border text-blue-600 bg-blue-50 border-blue-200">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
                Sincronizando datos Odoo…
            </span>
        );
    }
    if (error) {
        return (
            <span className="inline-flex items-center gap-1.5 text-[8px] font-black uppercase px-2.5 py-1 rounded-full border text-red-600 bg-red-50 border-red-200">
                <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                Error cargando datos Odoo
            </span>
        );
    }
    return (
        <span className="inline-flex items-center gap-1.5 text-[8px] font-black uppercase px-2.5 py-1 rounded-full border text-emerald-600 bg-emerald-50 border-emerald-200">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            Datos Odoo al día
        </span>
    );
}

function ChartTooltip({ active, payload, label }) {
    if (!active || !payload?.length) return null;
    return (
        <div className="bg-white rounded-md px-4 py-3 text-[10px]">
            <p className="font-black text-slate-500 mb-1 uppercase">{label}</p>
            {payload.map((p, i) => (
                <p key={i} style={{ color: p.color }} className="font-bold">
                    {p.name}: {p.value >= 1000 ? fmtM(p.value) : fmt(p.value)}
                </p>
            ))}
        </div>
    );
}

// ── page ──────────────────────────────────────────────────────────────────────
const PERIODOS = [
    { key: 'mes', label: 'Mes Actual' },
    { key: 'all', label: 'Todo' },
]; // Se puede agregar más períodos según sea necesario

export default function MedicoDetalle({
    auth, medico, tipoDocumentoOdoo = null, periodoActivo = 'mes', fechaDesdeActiva = null, fechaHastaActiva = null,
    esTemporal = false, documentoBase,
    txStats, tendencia, topProductos,
    porLaboratorio, todosProductos, transacciones = [],
    tarifasSinClasificar = { total: 0, lineas: 0, tarifas: [] },
    visitasStats, visitas, visitadoresAsignados,
    categoriaHistorial = [],
})  {
    const [tabActiva, setTabActiva] = useState('visitadores');
    const tabsRef = useRef(null);
    const [limLab, setLimLab]       = useState(50);
    const [limProd, setLimProd]     = useState(50);
    const [busquedaProd, setBusquedaProd] = useState('');
    const [ordenProd, setOrdenProd]       = useState('valor_desc'); // 'valor_desc' | 'valor_asc' | 'alfa'
    const [mostrarCalendario, setMostrarCalendario] = useState(false);
    const [fechaDesdeInput, setFechaDesdeInput] = useState(fechaDesdeActiva || '');
    const [fechaHastaInput, setFechaHastaInput] = useState(fechaHastaActiva || '');
    const [observacionActiva, setObservacionActiva] = useState(null);
    // Estado para abrir/cerrar el modal de EDICIÓN de observación
const [visitaAEditar, setVisitaAEditar] = useState(null); // Guarda el objeto de la visita
const [textoObservacion, setTextoObservacion] = useState(''); // Guarda el texto mientras escribe
const [guardandoObs, setGuardandoObs] = useState(false); // Spinner de carga al guardar

    // Estado para el modal de OBSERVACIONES DEL MÉDICO (a nivel de perfil, no por visita)
    const [observacionMedicoAbierta, setObservacionMedicoAbierta] = useState(false);
    const [textoObservacionMedico, setTextoObservacionMedico] = useState(medico.observaciones ?? '');
    const [guardandoObsMedico, setGuardandoObsMedico] = useState(false);
    const [editandoObservacion, setEditandoObservacion] = useState(false);

    // ── Tab Transacciones (órdenes/facturas Odoo) ───────────────────
    const [filtroTx, setFiltroTx]                   = useState('venta');
    const [excluirCanceladosTx, setExcluirCanceladosTx] = useState(true);
    const [fechaDesdeTx, setFechaDesdeTx]           = useState('');
    const [fechaHastaTx, setFechaHastaTx]           = useState('');
    const [filtroCobro, setFiltroCobro]             = useState('todos'); // 'todos' | 'pendiente' | 'vencida' — disparado desde la tarjeta Cartera

    const [sincronizando, setSincronizando] = useState(false);
    const [syncMsg, setSyncMsg] = useState(null); // { tipo: 'ok' | 'error', texto: string }
    const [cargandoAlertas, setCargandoAlertas] = useState(false);

    // ── Estado de carga al cambiar período/fecha (recarga props vía Inertia) ──
    const [cargandoDatos, setCargandoDatos] = useState(false);
    const [errorCargaDatos, setErrorCargaDatos] = useState(false);

    const irAPeriodo = (params) => {
        router.get(
            route('Gmedicos.showPorDocumento', documentoBase ?? medico.documento),
            params,
            {
                preserveScroll: true,
                onStart:   () => { setCargandoDatos(true); setErrorCargaDatos(false); },
                onFinish:  () => setCargandoDatos(false),
                onError:   () => setErrorCargaDatos(true),
                onSuccess: () => setMostrarCalendario(false),
            }
        );
    };

    const handleAnalizarAlertas = () => {
        setCargandoAlertas(true);
        router.visit(route('Gmedicos.alertasPorDocumento', documentoBase ?? medico.documento), {
            onFinish: () => setCargandoAlertas(false),
        });
    };

    const handleAbrirObservaciones = () => {
        setTextoObservacionMedico(medico.observaciones ?? '');
        setEditandoObservacion(!medico.observaciones); // Habilitar edición si está vacío de inicio
        setObservacionMedicoAbierta(true);
    };

    const handleGuardarObservacionMedico = () => {
        if (!medico.id) return; // médicos temporales (aún sin registrar) no tienen id real

        setGuardandoObsMedico(true);
        router.patch(route('Gmedicos.observaciones', medico.id), {
            observaciones: textoObservacionMedico,
        }, {
            preserveScroll: true,
            onSuccess: () => {
                setObservacionMedicoAbierta(false);
                setEditandoObservacion(false);
            },
            onError:   () => alert('Ocurrió un error al guardar la observación'),
            onFinish:  () => setGuardandoObsMedico(false),
        });
    };

    const handleSincronizarCategoria = () => {
        setSincronizando(true);
        setSyncMsg(null);
        router.post(route('Gmedicos.sincronizarCategoria', documentoBase ?? medico.documento), {}, {
            preserveScroll: true,
            onSuccess: (page) => {
                const flash = page.props.flash ?? {};
                setSyncMsg(flash.success ? { tipo: 'ok', texto: flash.success } : { tipo: 'error', texto: flash.error ?? 'No se pudo sincronizar.' });
            },
            onError: () => setSyncMsg({ tipo: 'error', texto: 'No se pudo sincronizar.' }),
            onFinish: () => setSincronizando(false),
        });
    };

    const handleGuardarObservacion = async () => {
    if (!visitaAEditar) return;
    
    setGuardandoObs(true);
    try {
        // ⚠️ REEMPLAZA ESTA LÍNEA por tu llamada real a la API/Supabase/Firebase/Odoo
        // Ejemplo: await api.put(`/visitas/${visitaAEditar.id}`, { observaciones: textoObservacion });

        // Actualizamos dinámicamente en el estado local de React para que se refleje al instante
        visitaAEditar.observaciones = textoObservacion;
        visitaAEditar.comentarios = textoObservacion; 

        // Cerrar modal
        setVisitaAEditar(null);
        setTextoObservacion('');
    } catch (error) {
        console.error("Error al guardar observación:", error);
        alert("Ocurrió un error al guardar la observación");
    } finally {
        setGuardandoObs(false);
    }
};
    const handlePeriodoPersonalizado = () => {
        if (!fechaDesdeInput || !fechaHastaInput) return;
        irAPeriodo({ periodo: 'custom', fecha_desde: fechaDesdeInput, fecha_hasta: fechaHastaInput });
    };

    // Los datos de Odoo (txStats, tendencia, productos...) siempre vienen
    // resueltos desde el controller en la carga inicial (show/showPorDocumento),
    // no hay una carga diferida del lado del cliente.
    const odoo = {
        txStats:        txStats ?? null,
        tendencia:      tendencia ?? [],
        topProductos:   topProductos ?? [],
        porLaboratorio: porLaboratorio ?? [],
        todosProductos: todosProductos ?? [],
    };
    const odooLoading = cargandoDatos;
    const odooError   = errorCargaDatos;

    const pieEstados = [
        { name: 'Efectivas',      value: Number(visitasStats?.efectivas      ?? 0), color: ESTADO_COLOR.efectiva },
        { name: 'Programadas',    value: Number(visitasStats?.programadas     ?? 0), color: ESTADO_COLOR.programada },
        { name: 'Reprogramadas',  value: Number(visitasStats?.reprogramadas   ?? 0), color: ESTADO_COLOR.reprogramada },
        { name: 'Canceladas',     value: Number(visitasStats?.canceladas      ?? 0), color: ESTADO_COLOR.cancelada },
        { name: 'No contactados', value: Number(visitasStats?.no_contactados  ?? 0), color: ESTADO_COLOR['No contactado'] },
    ].filter(e => e.value > 0);

    const tendenciaData = (odoo.tendencia ?? []).map(d => ({
        label:     d.mes,
        comprado:  Number(d.valor_comprado),
        formulado: Number(d.valor_formulado),
    })).slice(-12);

    const prodData = (odoo.topProductos ?? []).map(p => ({
        name:      p.nombre,
        valor:     Number(p.valor_comprado),
        formulado: Number(p.valor_formulado),
        unidades:  Number(p.unidades),
    }));

    const geoCoords = (() => {
        if (!medico.geolocalizacion) return null;
        const [lat, lng] = medico.geolocalizacion.split(',').map(Number);
        if (isNaN(lat) || isNaN(lng)) return null;
        return { lat, lng };
    })();

    const hoyISO = new Date().toISOString().split('T')[0];
    const esFacturaVencida = tx => (Number(tx.saldo_pendiente) || 0) > 0 && tx.fecha_vence && tx.fecha_vence < hoyISO;

    const transaccionesFiltradas = (transacciones ?? []).filter(tx => {
        if (filtroTx === 'venta'   ? !tx.origen.includes('Venta') : !tx.origen.includes('Factura')) return false;
        if (excluirCanceladosTx && tx.estado === 'cancel') return false;
        if (filtroCobro === 'pendiente' && !((Number(tx.saldo_pendiente) || 0) > 0)) return false;
        if (filtroCobro === 'vencida'   && !esFacturaVencida(tx)) return false;
        if (tx.fecha) {
            const txDate = new Date(tx.fecha).toISOString().split('T')[0];
            if (fechaDesdeTx && txDate < fechaDesdeTx) return false;
            if (fechaHastaTx && txDate > fechaHastaTx) return false;
        } else if (fechaDesdeTx || fechaHastaTx) {
            return false;
        }
        return true;
    });
    const totalTxFiltrado = transaccionesFiltradas.reduce((acc, tx) => acc + (Number(tx.total) || 0), 0);
    const baseTxFiltrada   = transaccionesFiltradas.reduce((acc, tx) => acc + (Number(tx.base_imponible) || 0), 0);
    const impuestosTxFiltrados = transaccionesFiltradas.reduce((acc, tx) => acc + (Number(tx.impuestos) || 0), 0);

    // ── Cartera (cuentas por cobrar) — vista general de facturas, no
    // depende del pill Ventas/Facturas, refleja el estado ACTUAL de cobro. ──
    const facturasCartera = (transacciones ?? []).filter(tx => tx.origen.includes('Factura') && tx.estado !== 'cancel');
    const carteraPendiente = facturasCartera.reduce((acc, tx) => acc + (Number(tx.saldo_pendiente) || 0), 0);
    const facturasVencidas = facturasCartera.filter(esFacturaVencida);
    const carteraVencida = facturasVencidas.reduce((acc, tx) => acc + (Number(tx.saldo_pendiente) || 0), 0);

    const irACartera = (filtro = 'pendiente') => {
        setTabActiva('transacciones');
        setFiltroTx('factura');
        setFiltroCobro(filtro);
        tabsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    };

    const ESTADO_PAGO_BADGE = {
        paid:             { label: 'Pagada',   className: 'text-emerald-600 bg-emerald-50 border-emerald-100' },
        in_payment:       { label: 'En pago',  className: 'text-blue-500 bg-blue-50 border-blue-100' },
        partial:          { label: 'Parcial',  className: 'text-amber-600 bg-amber-50 border-amber-100' },
        not_paid:         { label: 'Pendiente', className: 'text-slate-500 bg-slate-100 border-slate-200' },
        reversed:         { label: 'Revertida', className: 'text-slate-400 bg-slate-50 border-slate-100' },
        invoicing_legacy: { label: 'Legado',    className: 'text-slate-400 bg-slate-50 border-slate-100' },
    };
    const badgeEstadoPago = (tx) => {
        if (!tx.origen.includes('Factura')) return null;
        const vencida = (Number(tx.saldo_pendiente) || 0) > 0 && tx.fecha_vence && tx.fecha_vence < hoyISO;
        if (vencida) return { label: 'Vencida', className: 'text-red-600 bg-red-50 border-red-100' };
        return ESTADO_PAGO_BADGE[tx.estado_pago] ?? { label: tx.estado_pago ?? '—', className: 'text-slate-400 bg-slate-50 border-slate-100' };
    };

    return (
        <PanelAdmin user={auth?.user}>
            <Head title={`${medico.nombre} ${medico.apellido} · Detalle`} />

            {/* ── OVERLAY: carga al analizar alertas ── */}
            {cargandoAlertas && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-white/60 backdrop-blur-sm">
                    <div className="bg-white rounded-2xl shadow-xl px-10 py-8 flex flex-col items-center gap-3">
                        <FaSpinner className="text-3xl text-blue-500 animate-spin" />
                        <p className="text-[11px] font-black uppercase tracking-widest text-slate-500">
                            Analizando alertas del médico…
                        </p>
                    </div>
                </div>
            )}

            <div className="w-full min-h-screen bg-white pb-12">

                {/* ── HEADER ───────────────────────────────────────── */}
                <div className="w-full bg-white px-6 py-3">
                    <Link href={route('Gmedicos.index')}
                          className="inline-flex items-center gap-1.5 text-[9px] font-black uppercase text-slate-400 hover:text-blue-600 transition mb-1.5">
                        <FaArrowLeft className="text-[8px]" /> Volver a Médicos
                    </Link>
                    <div className="flex items-start justify-between gap-4 flex-wrap">
                        <div className="min-w-0">
                            <div className="flex items-baseline gap-2 flex-wrap">
                                <h1 className="text-[19px] font-black text-slate-800 leading-none uppercase">
                                    {medico.nombre} {medico.apellido}
                                </h1>
                                <span className="text-[9px] font-black uppercase tracking-widest text-slate-300">Perfil del médico</span>
                            </div>
                         <p className="text-[10px] text-slate-400 mt-1 flex flex-wrap items-center gap-x-3 gap-y-1">
    {/* Documento */}
    <span>{tipoDocumentoOdoo ?? medico.tipo_documento?.nombre ?? 'Doc.'}: {medico.documento}</span>

    {/* Especialidad */}
    {medico.especialidad && (
        <span className="text-blue-500 font-bold uppercase">{medico.especialidad}</span>
    )}

   {/* Dirección / Ubicación (Clickeable a Google Maps) */}
{(medico.direccion_detalles || medico.direccion) && (
    <a
        href={
            geoCoords 
                ? `https://www.google.com/maps?q=${geoCoords.lat},${geoCoords.lng}` 
                : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent((medico.direccion_detalles || medico.direccion) + ', Bogota, Colombia')}`
        }
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-1 text-slate-500 hover:text-blue-600 font-medium transition group"
        title="Ver en Google Maps"
    >
        <FaLocationDot className="text-rose-400 group-hover:text-blue-600 transition" />
        <span className="underline decoration-slate-300 underline-offset-2 group-hover:decoration-blue-600">
            {medico.direccion_detalles || medico.direccion}
        </span>
    </a>
)}

    {/* Teléfono / Celular (Alineado junto a la ubicación) */}
 
{/* Teléfono Fijo o Principal */}
{(medico.telefono || medico.telefono_contacto) && (
    <span className="flex items-center gap-1 font-medium text-slate-600">
        <FaPhone className="text-emerald-500 text-[9px]" /> 
        {medico.telefono || medico.telefono_contacto}
    </span>
)}

{/* Teléfono Móvil / Celular */}
{medico.celular && (
    <span className="flex items-center gap-1 font-medium text-slate-600">
        <FaMobileScreen className="text-emerald-500 text-[11px]" /> 
        {medico.celular}
    </span>
)}

{/* Si no hay ningún número registrado */}
{!medico.telefono && !medico.celular && !medico.telefono_contacto && (
    <span className="flex items-center gap-1 text-slate-300 italic">
        <FaPhone className="text-slate-300 text-[9px]" /> Sin teléfono
    </span>
)}

    {/* Horario de Atención */}
    {medico.horario_atencion && (
        <span className="flex items-center gap-1">
            <FaClock className="text-amber-400" /> {medico.horario_atencion}
        </span>
    )}

 {(medico.mes_nacimiento || medico.dia_nacimiento) && (
    <span className="flex items-center gap-1 font-medium text-slate-600">
        <FaCalendarDays className="text-blue-500 text-[10px]" /> 
        Cumpleaños: {medico.dia_nacimiento ?? '—'} / {formatoMesCompleto(medico.mes_nacimiento)}
    </span>
)}

    {/* Enlace al mapa */}
    {geoCoords && (
        <a href={`https://www.google.com/maps?q=${geoCoords.lat},${geoCoords.lng}`}
           target="_blank" rel="noopener noreferrer"
           className="flex items-center gap-1 text-blue-500 hover:text-blue-700 font-bold transition">
            <FaLocationDot className="text-blue-400" /> ver mapa
        </a>
    )}
</p>
                        </div>

                        {/* ── CARTERA ──────────────────────────────────────── */}
                        {carteraPendiente > 0 && (
                            <div className="flex items-center gap-5 rounded-md bg-white px-4 py-2 shrink-0">
                                <span className={`flex items-center gap-1.5 text-[9px] font-black uppercase tracking-widest shrink-0 ${carteraVencida > 0 ? 'text-red-600' : 'text-blue-600'}`}>
                                    <FaFileInvoiceDollar className="text-xs" /> Cartera
                                </span>
                                <button type="button" onClick={() => irACartera('pendiente')}
                                    className="text-left hover:opacity-70 transition-opacity">
                                    <p className="text-[8px] font-black uppercase text-slate-400 tracking-widest mb-0.5">Pendiente de cobro</p>
                                    <p className="text-[13px] font-black text-slate-800 leading-none">{fmtM(carteraPendiente)}</p>
                                </button>
                                <button type="button" onClick={() => irACartera('vencida')}
                                    className="text-left hover:opacity-70 transition-opacity">
                                    <p className="text-[8px] font-black uppercase text-red-400 tracking-widest mb-0.5">Vencida</p>
                                    <p className={`text-[13px] font-black leading-none ${carteraVencida > 0 ? 'text-red-600' : 'text-slate-800'}`}>
                                        {fmtM(carteraVencida)}
                                    </p>
                                </button>
                                <button type="button" onClick={() => irACartera('vencida')}
                                    className="text-left hover:opacity-70 transition-opacity">
                                    <p className="text-[8px] font-black uppercase text-slate-400 tracking-widest mb-0.5">Facturas vencidas</p>
                                    <p className="text-[13px] font-black text-slate-800 leading-none">{facturasVencidas.length}</p>
                                </button>
                            </div>
                        )}

                        <div className="flex flex-wrap items-stretch gap-3">
                            {/* Clasificación: categoría + visitador asignado */}
                            {(medico.categoria || medico.visitador) && (
                                <div className="flex flex-wrap items-center gap-1.5">
                                    {medico.categoria && (
                                        <span className="inline-flex items-center gap-1.5 text-[9px] font-black text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200 uppercase">
                                            {medico.categoria.nombre}
                                            <TendenciaCategoria tendencia={medico.categoria_tendencia} />
                                        </span>
                                    )}
                                    {medico.visitador && (
                                        <span className="text-[9px] font-black text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 uppercase">
                                            {medico.visitador.nombre} {medico.visitador.apellido}
                                        </span>
                                    )}
                                </div>
                            )}

                            {/* Acción */}
                            <button
                                type="button"
                                onClick={handleAbrirObservaciones}
                                className={`px-3 py-1.5 rounded-md text-[9px] font-black uppercase tracking-wider transition-all shadow-sm active:scale-95 inline-flex items-center gap-1.5 self-center border ${
                                    medico.observaciones
                                        ? 'bg-amber-50 text-amber-600 border-amber-200 hover:bg-amber-100'
                                        : 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100'
                                }`}
                            >
                                <FaCommentDots className="text-[10px]" />
                                Observaciones
                            </button>

                            <button
                                type="button"
                                onClick={handleAnalizarAlertas}
                                disabled={cargandoAlertas}
                                className="bg-red-50 text-red-600 border border-red-200 hover:bg-red-100 px-3 py-1.5 rounded-md text-[9px] font-black uppercase tracking-wider transition-all shadow-sm active:scale-95 inline-flex items-center gap-1.5 self-center disabled:opacity-60 disabled:cursor-not-allowed"
                            >
                                {cargandoAlertas
                                    ? <FaSpinner className="text-[10px] animate-spin" />
                                    : <FaFlask className="text-[10px]" />
                                }
                                Analizar Alertas
                            </button>
                        </div>
                    </div>

                    {/* ── HISTORIAL DE CATEGORÍA + PERÍODO — misma fila ── */}
                    <div className="mt-3 pt-3 flex flex-wrap items-center justify-between gap-3">

                        {/* ── HISTORIAL DE CATEGORÍA ─────────────────────────── */}
                        {!esTemporal && (() => {
                            const cronologico = [...categoriaHistorial].reverse();
                            const tierColors = colorPorNivelCategoria(cronologico);
                            return (
                                <div className="flex-1 min-w-0 mx-2">
                                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                                        <p className="text-[8px] font-black uppercase tracking-widest text-slate-400 whitespace-nowrap">
                                            Historial de categoría (mes a mes)
                                        </p>
                                        <button type="button" onClick={handleSincronizarCategoria} disabled={sincronizando}
                                            title="Vuelve a consultar en Odoo todos los datos de este médico: KPIs, tendencia, productos, transacciones, cartera y categoría."
                                            className="flex items-center gap-1 text-[8px] font-black uppercase text-blue-500 hover:text-blue-700 disabled:opacity-50 transition-colors shrink-0">
                                            {sincronizando ? <FaSpinner className="animate-spin text-[8px]" /> : <FaRotate className="text-[8px]" />}
                                            Sincronizar con Odoo
                                        </button>
                                    </div>
                                    {syncMsg && (
                                        <p className={`flex items-center gap-1 text-[8px] font-bold mb-1 ${syncMsg.tipo === 'ok' ? 'text-emerald-600' : 'text-red-500'}`}>
                                            {syncMsg.tipo === 'ok' && <FaCheck className="text-[8px]" />}
                                            {syncMsg.texto}
                                        </p>
                                    )}
                                    {categoriaHistorial.length === 0 && (
                                        <p className="text-[9px] text-slate-300 italic">Sin historial calculado — usa "Sincronizar con Odoo" para generarlo.</p>
                                    )}
                                    <div className="overflow-x-auto">
                                    <div className="flex gap-1 items-center flex-nowrap w-max">
                                        {cronologico.map((h, idx) => {
                                            const color = tierColors.get(parseFloat(h.categoria?.valor_minimo)) ?? '#94a3b8';
                                            const trend = idx > 0 ? tendenciaEntre(cronologico[idx - 1], h) : null;
                                            return (
                                                <React.Fragment key={h.id}>
                                                    {idx > 0 && (
                                                        <div className="flex items-center justify-center w-4 shrink-0">
                                                            <TendenciaCategoria tendencia={trend} />
                                                        </div>
                                                    )}
                                                    <div
                                                        className="flex flex-col items-center gap-1 rounded-md px-3 py-2 min-w-[74px] border shrink-0 cursor-default"
                                                        style={{ borderColor: `${color}55`, background: `${color}12` }}
                                                        title={`Comprado: ${fmtM(h.valor_comprado)} · Formulado: ${fmtM(h.valor_formulado)} · Total: ${fmtM(h.valor_total)}`}
                                                    >
                                                        <span className="text-[8px] font-black text-slate-400 uppercase">
                                                            {h.mes?.slice(0, 7)}
                                                        </span>
                                                        <span className="text-[11px] font-black" style={{ color }}>
                                                            {h.categoria?.nombre ?? '—'}
                                                        </span>
                                                    </div>
                                                </React.Fragment>
                                            );
                                        })}
                                    </div>
                                    </div>
                                </div>
                            );
                        })()}

                        {/* ── SELECTOR DE PERÍODO ─────────────────────────── */}
                        <div className="flex flex-wrap items-center gap-2 relative">
                            <p className="text-[9px] font-black uppercase tracking-widest text-slate-400 mr-1">Período:</p>
                            <OdooStatusBadge loading={odooLoading} error={odooError} />
                            {PERIODOS.map(p => (
                                <button
                                    key={p.key}
                                    onClick={() => irAPeriodo({ periodo: p.key })}
                                    disabled={cargandoDatos}
                                    className={`px-3 py-1 rounded-md text-[9px] font-black uppercase tracking-wide transition-all disabled:opacity-50 disabled:cursor-wait ${
                                        periodoActivo === p.key
                                            ? 'bg-blue-600 text-white shadow-sm'
                                            : 'text-slate-400 hover:text-slate-700 border border-slate-200 hover:border-slate-300'
                                    }`}
                                >
                                    {p.label}
                                </button>
                            ))}

                            <button
                                onClick={() => setMostrarCalendario(v => !v)}
                                disabled={cargandoDatos}
                                className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-[9px] font-black uppercase tracking-wide transition-all disabled:opacity-50 disabled:cursor-wait ${
                                    periodoActivo === 'custom'
                                        ? 'bg-blue-600 text-white shadow-sm'
                                        : 'text-slate-400 hover:text-slate-700 border border-slate-200 hover:border-slate-300'
                                }`}
                            >
                                <FaCalendarDays className="h-3 w-3" />
                                {periodoActivo === 'custom' && fechaDesdeActiva && fechaHastaActiva
                                    ? `${fechaDesdeActiva} → ${fechaHastaActiva}`
                                    : 'Personalizado'}
                            </button>

                            {mostrarCalendario && (
                            <div className="absolute top-full left-0 mt-2 z-40 bg-white rounded-md p-4 flex flex-col gap-3 w-full max-w-xs">
                                <div className="flex items-center justify-between">
                                    <p className="text-[9px] font-black uppercase tracking-widest text-slate-400">Rango personalizado</p>
                                    <button onClick={() => setMostrarCalendario(false)} className="text-slate-300 hover:text-slate-500">
                                        <FaXmark size={12} />
                                    </button>
                                </div>
                                <div className="flex flex-col gap-2">
                                    <label className="text-[9px] font-black uppercase text-slate-400">
                                        Desde
                                        <input
                                            type="date"
                                            value={fechaDesdeInput}
                                            max={fechaHastaInput || undefined}
                                            onChange={e => setFechaDesdeInput(e.target.value)}
                                            className="mt-1 w-full bg-slate-50 border border-slate-200 rounded-md px-3 py-2 text-xs font-bold text-slate-700 outline-none focus:ring-2 focus:ring-blue-300"
                                        />
                                    </label>
                                    <label className="text-[9px] font-black uppercase text-slate-400">
                                        Hasta
                                        <input
                                            type="date"
                                            value={fechaHastaInput}
                                            min={fechaDesdeInput || undefined}
                                            onChange={e => setFechaHastaInput(e.target.value)}
                                            className="mt-1 w-full bg-slate-50 border border-slate-200 rounded-md px-3 py-2 text-xs font-bold text-slate-700 outline-none focus:ring-2 focus:ring-blue-300"
                                        />
                                    </label>
                                </div>
                                <button
                                    onClick={handlePeriodoPersonalizado}
                                    disabled={!fechaDesdeInput || !fechaHastaInput || cargandoDatos}
                                    className="w-full py-2 rounded-md text-[10px] font-black uppercase tracking-wider bg-blue-600 text-white disabled:opacity-40 transition-all active:scale-95 flex items-center justify-center gap-1.5"
                                >
                                    {cargandoDatos && <FaSpinner className="animate-spin text-[10px]" />}
                                    {cargandoDatos ? 'Consultando…' : 'Aplicar'}
                                </button>
                            </div>
                            )}
                        </div>
                    </div>
                </div>

                <div className="px-8 pt-7 space-y-7">

                    {/* ── KPIs ─────────────────────────────────────────── */}
                    {/* Val./Unidades/Productos dependen de Odoo → skeleton mientras cargan.
                        Total visitas es local (visitasStats) → siempre instantáneo. */}
                    <div className="flex gap-3">
                        {odooLoading ? (
                            <>
                                <KpiSkeleton accent="#4184F0" />
                                <KpiSkeleton accent="#8b5cf6" />
                                <KpiSkeleton accent="#f59e0b" />
                                <KpiSkeleton accent="#ef4444" />
                                <KpiSkeleton accent="#ec4899" />
                                <KpiSkeleton accent="#10b981" />
                            </>
                        ) : (
                            <>
                                <KpiCard label="Val. comprado"   value={fmtM(odoo.txStats?.total_valor_comprado)}  accent="#4184F0" />
                                <KpiCard label="Val. formulado"  value={fmtM(odoo.txStats?.total_valor_formulado)} accent="#8b5cf6" />
                                <KpiCard label="Unidades Generales"        value={fmt(odoo.txStats?.total_unidades)}          accent="#f59e0b" />
                                {/* CORREGIDO: Se cambia total_unidades_compradas por unidades_compradas (o el mapeo real del backend) */}
                                <KpiCard label="Unidades compradas" value={fmt(odoo.txStats?.unidades_compradas ?? odoo.txStats?.total_unidades_compradas)} accent="#ef4444" />
                                <KpiCard label="Unidades formuladas" value={fmt(odoo.txStats?.unidades_formuladas ?? odoo.txStats?.total_unidades_formuladas)} accent="#ec4899" />
                                <KpiCard label="Productos"       value={fmt(odoo.txStats?.total_productos)}         accent="#10b981" sub={`${odoo.txStats?.meses_activo ?? 0} meses activo`} />
                            </>
                        )}
                        <KpiCard label="Total visitas"   value={fmt(visitasStats?.total)}              accent="#ef4444" sub={`${visitasStats?.efectivas ?? 0} efectivas`} />
                    </div>

                    {/* ── Aviso: tarifas sin clasificar ───────────────────
                        Líneas cuya tarifa (pricelist) todavía no tiene
                        categoría en Configuración > Tarifas: se suman dentro
                        de "Val. comprado" para que no queden invisibles, y
                        aquí se detalla a qué tarifas corresponden. */}
                    {tarifasSinClasificar?.total > 0 && (
                        <div className="bg-amber-50 border border-amber-200 rounded-md px-5 py-4 flex items-start gap-3">
                            <FaTriangleExclamation className="text-amber-500 text-sm mt-0.5 shrink-0" />
                            <div className="min-w-0 flex-1">
                                <p className="text-[10px] font-black uppercase tracking-widest text-amber-700">
                                    {fmtM(tarifasSinClasificar.total)} contabilizados en "Val. comprado" desde tarifas sin clasificar
                                </p>
                                <p className="text-[9px] text-amber-600 mt-0.5">
                                    {tarifasSinClasificar.lineas} línea(s) usan una tarifa (pricelist) sin categoría asignada en Configuración → Tarifas. Clasifícalas para que cuenten donde corresponde.
                                </p>
                                <div className="flex flex-wrap gap-2 mt-2">
                                    {tarifasSinClasificar.tarifas.map((t, i) => (
                                        <span key={i} className="inline-flex items-center gap-1.5 text-[9px] font-bold text-amber-700 bg-white border border-amber-200 rounded-full px-2.5 py-1">
                                            {t.nombre}
                                            <span className="text-amber-500 font-mono">{fmtM(t.valor)}</span>
                                            <span className="text-amber-400">· {t.lineas} lín.</span>
                                        </span>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}

                    {/* ── CHARTS ───────────────────────────────────────── */}
                    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">

                        {/* Tendencia valor */}
                        <div className="xl:col-span-2 bg-white rounded-md p-6">
                            <p className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-1">Histórico</p>
                            <p className="text-[13px] font-black text-slate-800 mb-4">Valor comprado y formulado</p>
                            {odooLoading ? (
                                <ChartSkeleton height={320} />
                            ) : tendenciaData.length === 0 ? (
                                <div className="flex items-center justify-center h-48 text-slate-300 text-[11px]">Sin transacciones</div>
                            ) : (
                                <ResponsiveContainer width="100%" height={320}>
                                    <AreaChart data={tendenciaData} margin={{ top: 4, right: 10, left: 0, bottom: 0 }}>
                                        <defs>
                                            <linearGradient id="gcM" x1="0" y1="0" x2="0" y2="1">
                                                <stop offset="5%"  stopColor="#4184F0" stopOpacity={0.28} />
                                                <stop offset="95%" stopColor="#4184F0" stopOpacity={0} />
                                            </linearGradient>
                                            <linearGradient id="gfM" x1="0" y1="0" x2="0" y2="1">
                                                <stop offset="5%"  stopColor="#8b5cf6" stopOpacity={0.28} />
                                                <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                                            </linearGradient>
                                        </defs>
                                        <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                                        <XAxis dataKey="label" tick={{ fontSize: 9, fontWeight: 700, fill: '#94a3b8' }} />
                                        <YAxis tickFormatter={v => fmtM(v)} tick={{ fontSize: 8, fill: '#94a3b8' }} width={52} />
                                        <Tooltip content={<ChartTooltip />} />
                                        <Legend wrapperStyle={{ fontSize: 10, fontWeight: 700 }} />
                                        <Area type="monotone" dataKey="comprado" name="Comprado" stroke="#4184F0" fill="url(#gcM)" strokeWidth={2.5} dot={false} />
                                        <Area type="monotone" dataKey="formulado" name="Formulado" stroke="#8b5cf6" fill="url(#gfM)" strokeWidth={2.5} dot={false} />
                                    </AreaChart>
                                </ResponsiveContainer>
                            )}
                        </div>

                        {/* Pie visitas + top productos */}
                        <div className="flex flex-col gap-5">

                            {/* Pie estado visitas */}
                            <div className="bg-white rounded-md p-5 flex-1">
                                <p className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-1">Visitas</p>
                                <p className="text-[12px] font-black text-slate-800 mb-3">Estado general</p>
                                {pieEstados.length === 0 ? (
                                    <div className="flex items-center justify-center h-24 text-slate-300 text-[11px]">Sin visitas</div>
                                ) : (
                                    <div className="flex items-center gap-3">
                                        <ResponsiveContainer width={90} height={90}>
                                            <PieChart>
                                                <Pie data={pieEstados} cx="50%" cy="50%" innerRadius={28} outerRadius={42}
                                                     dataKey="value" paddingAngle={3}>
                                                    {pieEstados.map((e, i) => <Cell key={i} fill={e.color} />)}
                                                </Pie>
                                            </PieChart>
                                        </ResponsiveContainer>
                                        <ul className="space-y-1.5 flex-1">
                                            {pieEstados.map((e, i) => (
                                                <li key={i} className="flex items-center gap-1.5 text-[9px]">
                                                    <span className="w-2 h-2 rounded-full shrink-0" style={{ background: e.color }} />
                                                    <span className="font-bold text-slate-600 flex-1">{e.name}</span>
                                                    <span className="font-black text-slate-800">{e.value}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                )}
                            </div>

                            {/* Top productos */}
                            <div className="bg-white rounded-md p-5 flex-1">
                                <p className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-1">Productos</p>
                                <p className="text-[12px] font-black text-slate-800 mb-1">Top por valor comprado y formulado</p>
                                <LeyendaCompradoFormulado className="mb-3" />
                                <div className="space-y-3">
                                    {odooLoading ? (
                                        <>
                                            <BarRowSkeleton />
                                            <BarRowSkeleton />
                                            <BarRowSkeleton />
                                        </>
                                    ) : prodData.map((p, i) => (
                                            <div key={i}>
                                                <div className="flex justify-between mb-1">
                                                    <span className="text-[9px] font-bold text-slate-600 truncate flex-1 pr-2">{p.name}</span>
                                                    <div className="flex gap-2 shrink-0">
                                                        <span className="text-[9px] font-black" style={{ color: COLOR_COMPRADO }}>{fmtM(p.valor)}</span>
                                                        <span className="text-[9px] font-black" style={{ color: COLOR_FORMULADO }}>{fmtM(p.formulado)}</span>
                                                    </div>
                                                </div>
                                                <BarraComparativa comprado={p.valor} formulado={p.formulado} />
                                            </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* ── TABS: Visitadores / Visitas ───────────────────── */}
                    <div ref={tabsRef} className="bg-white rounded-md overflow-hidden">

                        <div className="flex">
                            {[
                                { id: 'visitadores',   label: 'Visitadores asignados',   icon: <FaUserDoctor />,        count: visitadoresAsignados?.length },
                                { id: 'laboratorios',  label: 'Laboratorios y productos', icon: <FaFlask />,             count: odooLoading ? '…' : odoo.todosProductos?.length },
                                { id: 'transacciones', label: 'Transacciones',           icon: <FaFileInvoiceDollar />, count: transacciones?.length },
                                { id: 'visitas',       label: 'Historial de visitas',     icon: <FaCalendarCheck />,     count: visitas?.length },
                            ].map(tab => (
                                <button key={tab.id} onClick={() => setTabActiva(tab.id)}
                                    className={`flex items-center gap-2 px-6 py-4 text-[10px] font-black uppercase tracking-wider border-b-2 transition-colors ${
                                        tabActiva === tab.id
                                            ? 'border-blue-600 text-blue-600 bg-blue-50/30'
                                            : 'border-transparent text-slate-400 hover:text-slate-600'
                                    }`}>
                                    {tab.icon} {tab.label}
                                    <span className="bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded text-[8px] font-black">{tab.count}</span>
                                </button>
                            ))}
                        </div>

                        {/* Tab: Visitas */}
{tabActiva === 'visitadores' && (
    <>
        <table className="w-full text-left border-collapse">
            <thead>
                <tr className="bg-blue-600">
                    <th className="px-5 py-3 text-white text-[9px] font-black uppercase border-r border-blue-500">Visitador</th>
                    <th className="px-5 py-3 text-white text-[9px] font-black uppercase border-r border-blue-500 text-center">Estado</th>
                    <th className="px-5 py-3 text-white text-[9px] font-black uppercase border-r border-blue-500 text-center">Total Visitas</th>
                    <th className="px-5 py-3 text-white text-[9px] font-black uppercase text-center">Efectivas</th>
                </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
                {(visitadoresAsignados ?? []).length === 0 ? (
                    <tr>
                        <td colSpan={4} className="px-5 py-10 text-center text-[11px] text-slate-300 font-bold">
                            Sin visitadores asignados
                        </td>
                    </tr>
                ) : (
                    (visitadoresAsignados ?? []).map((v, i) => (
                        <tr key={v.id || i} className="hover:bg-blue-50/20 transition-colors">
                            {/* 1. NOMBRE DEL VISITADOR */}
                            <td className="px-5 py-2.5 text-[11px] font-bold text-slate-700 border-r border-slate-50">
                                {v.nombre || v.visitador?.nombre || 'Sin Nombre'}
                            </td>

                            {/* 2. ESTADO (Si es el asignado actual) */}
                            <td className="px-5 py-2.5 text-center border-r border-slate-50">
                                {v.es_asignado ? (
                                    <span className="px-2 py-0.5 bg-emerald-50 text-emerald-600 border border-emerald-200 rounded text-[9px] font-black uppercase">
                                        Asignado
                                    </span>
                                ) : (
                                    <span className="px-2 py-0.5 bg-slate-100 text-slate-400 rounded text-[9px] font-bold uppercase">
                                        Histórico
                                    </span>
                                )}
                            </td>

                            {/* 3. TOTAL VISITAS */}
                            <td className="px-5 py-2.5 text-center text-[11px] font-bold text-slate-600 border-r border-slate-50">
                                {v.total_visitas ?? 0}
                            </td>

                            {/* 4. VISITAS EFECTIVAS */}
                            <td className="px-5 py-2.5 text-center text-[11px] font-bold text-slate-600">
                                {v.efectivas ?? 0}
                            </td>
                        </tr>
                    ))
                )}
            </tbody>
        </table>
    </>
)}
                        {/* Tab: Laboratorios y productos */}
                        {tabActiva === 'laboratorios' && (
                                <div className="p-6 space-y-6">

                                    {/* Laboratorios */}
                                    <div>
                                        <div className="flex items-center justify-between mb-3">
                                            <p className="text-[9px] font-black uppercase tracking-widest text-slate-400">Por laboratorio</p>
                                            <div className="flex items-center gap-3">
                                                <LeyendaCompradoFormulado />
                                                <span className="text-[9px] text-slate-400">Mostrar</span>
                                                <select
                                                    value={limLab}
                                                    onChange={e => setLimLab(e.target.value === 'all' ? Infinity : Number(e.target.value))}
                                                    className="text-[9px] font-black border border-slate-200 rounded-md px-2 py-1 text-slate-600 bg-white focus:outline-none focus:ring-1 focus:ring-blue-400"
                                                >
                                                    {[5, 10, 20, 50].map(n => <option key={n} value={n}>{n}</option>)}
                                                    <option value="all">Todos</option>
                                                </select>
                                            </div>
                                        </div>
                                        {odooLoading ? (
                                            <div className="space-y-4">
                                                <BarRowSkeleton />
                                                <BarRowSkeleton />
                                                <BarRowSkeleton />
                                            </div>
                                        ) : (odoo.porLaboratorio ?? []).length === 0 ? (
                                            <p className="text-[10px] text-slate-300 text-center py-6">Sin datos</p>
                                        ) : (
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3">
                                                {(odoo.porLaboratorio ?? []).slice(0, limLab).map((lab, i) => (
                                                    <div key={i}>
                                                        <div className="flex flex-wrap justify-between items-baseline gap-x-2 mb-1">
                                                            <span className="text-[10px] font-black text-slate-700 uppercase">{lab.laboratorio}</span>
                                                            <div className="flex flex-wrap justify-end gap-x-3 gap-y-0.5 text-right">
                                                                <span className="text-[9px] font-black" style={{ color: COLOR_COMPRADO }}>{fmtM(lab.valor_comprado)}</span>
                                                                <span className="text-[9px] font-black" style={{ color: COLOR_FORMULADO }}>{fmtM(lab.valor_formulado)}</span>
                                                                <span className="text-[9px] text-slate-400">{fmtM(lab.unidades)} u.</span>
                                                                <span className="text-[9px] text-slate-400">{lab.total_productos} prod.</span>
                                                            </div>
                                                        </div>
                                                        <BarraComparativa comprado={Number(lab.valor_comprado)} formulado={Number(lab.valor_formulado)} />
                                                    </div>
                                                ))}
                                            </div>
                                        )}
                                    </div>

                                    {/* Tabla completa de productos */}
                                    <div>
                                        {/* ── Barra de herramientas ── */}
                                        <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                                            <p className="text-[9px] font-black uppercase tracking-widest text-slate-400">Detalle por producto</p>

                                            <div className="flex flex-wrap items-center gap-2 ml-auto">
                                                {/* Buscador */}
                                                <div className="relative">
                                                    <svg className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M21 21l-4.35-4.35M17 11A6 6 0 1 1 5 11a6 6 0 0 1 12 0z" />
                                                    </svg>
                                                    <input
                                                        type="text"
                                                        placeholder="Buscar producto..."
                                                        value={busquedaProd}
                                                        onChange={e => { setBusquedaProd(e.target.value); setLimProd(50); }}
                                                        className="pl-6 pr-3 py-1 text-[9px] font-semibold border border-slate-200 rounded-md text-slate-700 bg-white focus:outline-none focus:ring-1 focus:ring-blue-400 w-44 placeholder:text-slate-300"
                                                    />
                                                    {busquedaProd && (
                                                        <button
                                                            onClick={() => setBusquedaProd('')}
                                                            className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-500 transition"
                                                        >
                                                            <svg className="w-2.5 h-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" />
                                                            </svg>
                                                        </button>
                                                    )}
                                                </div>

                                                {/* Botones de orden */}
                                                <div className="flex items-center gap-1.5">
                                                    <button
                                                        onClick={() => setOrdenProd('valor_desc')}
                                                        title="Mayor a menor valor comprado"
                                                        className={`px-2.5 py-1 text-[8px] font-black uppercase tracking-wide rounded-md border transition-colors ${
                                                            ordenProd === 'valor_desc'
                                                                ? 'bg-blue-600 text-white border-blue-600'
                                                                : 'bg-white text-slate-400 border-slate-200 hover:text-slate-600 hover:border-slate-300'
                                                        }`}
                                                    >
                                                        $ ↓ Mayor
                                                    </button>
                                                    <button
                                                        onClick={() => setOrdenProd('valor_asc')}
                                                        title="Menor a mayor valor comprado"
                                                        className={`px-2.5 py-1 text-[8px] font-black uppercase tracking-wide rounded-md border transition-colors ${
                                                            ordenProd === 'valor_asc'
                                                                ? 'bg-blue-600 text-white border-blue-600'
                                                                : 'bg-white text-slate-400 border-slate-200 hover:text-slate-600 hover:border-slate-300'
                                                        }`}
                                                    >
                                                        $ ↑ Menor
                                                    </button>
                                                    <button
                                                        onClick={() => setOrdenProd('alfa')}
                                                        title="Orden alfabético"
                                                        className={`px-2.5 py-1 text-[8px] font-black uppercase tracking-wide rounded-md border transition-colors ${
                                                            ordenProd === 'alfa'
                                                                ? 'bg-blue-600 text-white border-blue-600'
                                                                : 'bg-white text-slate-400 border-slate-200 hover:text-slate-600 hover:border-slate-300'
                                                        }`}
                                                    >
                                                        A → Z
                                                    </button>
                                                </div>

                                                {/* Mostrar N */}
                                                <div className="flex items-center gap-1.5">
                                                    <span className="text-[9px] text-slate-400">Mostrar</span>
                                                    <select
                                                        value={limProd}
                                                        onChange={e => setLimProd(e.target.value === 'all' ? Infinity : Number(e.target.value))}
                                                        className="text-[9px] font-black border border-slate-200 rounded-md px-2 py-1 text-slate-600 bg-white focus:outline-none focus:ring-1 focus:ring-blue-400"
                                                    >
                                                        {[5, 10, 20, 50].map(n => <option key={n} value={n}>{n}</option>)}
                                                        <option value="all">Todos</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        {/* ── Tabla ── */}
                                        {(() => {
                                            const termino = busquedaProd.trim().toLowerCase();
                                            const filtrados = (odoo.todosProductos ?? [])
                                                .filter(p =>
                                                    !termino ||
                                                    (p.nombre ?? '').toLowerCase().includes(termino) ||
                                                    (p.codigo ?? '').toLowerCase().includes(termino) ||
                                                    (p.laboratorio ?? '').toLowerCase().includes(termino)
                                                )
                                                .slice()
                                                .sort((a, b) =>
                                                    ordenProd === 'alfa'
                                                        ? (a.nombre ?? '').localeCompare(b.nombre ?? '', 'es', { sensitivity: 'base' })
                                                        : ordenProd === 'valor_asc'
                                                            ? Number(a.valor_comprado) - Number(b.valor_comprado)
                                                            : Number(b.valor_comprado) - Number(a.valor_comprado)
                                                );

                                            const visibles = filtrados.slice(0, limProd === Infinity ? filtrados.length : limProd);

                                            return (
                                                <>
                                                    {termino && (
                                                        <p className="text-[9px] text-slate-400 mb-2">
                                                            {filtrados.length === 0
                                                                ? 'Sin resultados para "' + busquedaProd + '"'
                                                                : `${filtrados.length} resultado${filtrados.length !== 1 ? 's' : ''} para "${busquedaProd}"`
                                                            }
                                                        </p>
                                                    )}
                                                    <div className="overflow-x-auto">
                                                        <table className="w-full text-left border-collapse">
                                                            <thead>
                                                                <tr className="bg-blue-600">
                                                                    <th className="px-5 py-3 text-white text-[9px] font-black uppercase border-r border-blue-500">
                                                                        Producto
                                                                        {ordenProd === 'alfa' && <span className="ml-1 opacity-60">↑A-Z</span>}
                                                                    </th>
                                                                    <th className="px-5 py-3 text-white text-[9px] font-black uppercase border-r border-blue-500">Laboratorio</th>
                                                                    <th className="px-5 py-3 text-white text-[9px] font-black uppercase border-r border-blue-500 text-right">
                                                                        Val. comprado
                                                                        {ordenProd === 'valor' && <span className="ml-1 opacity-60">↓</span>}
                                                                    </th>
                                                                    <th className="px-5 py-3 text-white text-[9px] font-black uppercase border-r border-blue-500 text-right">Val. formulado</th>
                                                                    <th className="px-5 py-3 text-white text-[9px] font-black uppercase text-right">Unidades Compradas</th>
                                                                    <th className="px-5 py-3 text-white text-[9px] font-black uppercase text-right">Unidades Formuladas</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody className="divide-y divide-slate-50">
                                                                {odooLoading ? (
                                                                    Array.from({ length: 6 }).map((_, i) => (
                                                                        <tr key={i} className="animate-pulse">
                                                                            <td className="px-5 py-3 border-r border-slate-50"><div className="h-2.5 w-32 bg-slate-100 rounded" /></td>
                                                                            <td className="px-5 py-3 border-r border-slate-50"><div className="h-2.5 w-16 bg-slate-100 rounded" /></td>
                                                                            <td className="px-5 py-3 border-r border-slate-50"><div className="h-2.5 w-14 bg-slate-100 rounded ml-auto" /></td>
                                                                            <td className="px-5 py-3 border-r border-slate-50"><div className="h-2.5 w-14 bg-slate-100 rounded ml-auto" /></td>
                                                                            <td className="px-5 py-3"><div className="h-2.5 w-10 bg-slate-100 rounded ml-auto" /></td>
                                                                            <td className="px-5 py-3"><div className="h-2.5 w-10 bg-slate-100 rounded ml-auto" /></td>
                                                                        </tr>
                                                                    ))
                                                                ) : visibles.length === 0 ? (
                                                                    <tr>
                                                                        <td colSpan={4} className="px-5 py-10 text-center text-[11px] text-slate-300 font-bold">
                                                                            Sin productos{termino ? ` que coincidan con "${busquedaProd}"` : ''}
                                                                        </td>
                                                                    </tr>
                                                                ) : visibles.map((p, i) => (
                                                                    <tr key={i} className="hover:bg-blue-50/20 transition-colors">
                                                                        <td className="px-5 py-2.5 border-r border-slate-50">
                                                                            <p className="text-[10px] font-black text-slate-700 uppercase">{p.nombre}</p>
                                                                            <p className="text-[9px] text-slate-400">{p.codigo}</p>
                                                                        </td>
                                                                        <td className="px-5 py-2.5 border-r border-slate-50">
                                                                            <span className="text-[9px] font-black text-slate-600 bg-slate-100 px-2 py-0.5 rounded-md uppercase">
                                                                                {p.laboratorio ?? '—'}
                                                                            </span>
                                                                        </td>
                                                                        <td className="px-5 py-2.5 border-r border-slate-50 text-right">
                                                                            <span className="text-[10px] font-black text-indigo-600">{fmtM(p.valor_comprado)}</span>
                                                                        </td>
                                                                        <td className="px-5 py-2.5 border-r border-slate-50 text-right">
                                                                            <span className="text-[10px] font-black text-purple-500">{fmtM(p.valor_formulado)}</span>
                                                                        </td>
                                                                        <td className="px-5 py-2.5 text-right text-[10px] text-slate-500 font-bold">{fmt(p.unidades)}</td>
                                                                        <td className="px-5 py-2.5 text-right text-[10px] text-slate-500 font-bold">{fmt(p.unidades_formuladas)}</td>
                                                                    </tr>
                                                                ))}
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    {filtrados.length > visibles.length && (
                                                        <p className="text-center text-[9px] text-slate-300 mt-3 font-bold">
                                                            Mostrando {visibles.length} de {filtrados.length} productos
                                                        </p>
                                                    )}
                                                </>
                                            );
                                        })()}
                                    </div>

                                </div>
                        )}

                        {/* Tab: Transacciones (órdenes/facturas Odoo) */}
                        {tabActiva === 'transacciones' && (
                            <div>
                                <div className="flex items-center justify-between px-6 py-3 bg-slate-50/50 flex-wrap gap-3">
                                    <div className="flex items-center gap-3 shrink-0">
                                        <button type="button" onClick={() => setExcluirCanceladosTx(v => !v)}
                                            className={`flex items-center gap-1.5 text-[8px] font-black uppercase px-2.5 py-1.5 rounded-md border transition-colors ${
                                                excluirCanceladosTx
                                                    ? 'bg-red-50 border-red-200 text-red-600'
                                                    : 'bg-slate-100 border-slate-200 text-slate-400'
                                            }`}>
                                            <span className={`w-3 h-3 rounded-full border flex items-center justify-center transition-colors ${
                                                excluirCanceladosTx ? 'bg-red-500 border-red-500' : 'bg-white border-slate-300'
                                            }`}>
                                                {excluirCanceladosTx && <span className="text-white text-[7px] leading-none">✓</span>}
                                            </span>
                                            Excluir cancelados
                                        </button>
                                        <div className="flex items-center gap-1 bg-slate-200/60 p-0.5 rounded-md text-[9px] font-bold uppercase">
                                            {[
                                                { key: 'venta',   label: 'Ventas',   active: 'bg-indigo-600 text-white shadow-sm' },
                                                { key: 'factura', label: 'Facturas', active: 'bg-amber-600 text-white shadow-sm' },
                                            ].map(({ key, label, active }) => (
                                                <button key={key} type="button" onClick={() => { setFiltroTx(key); setFiltroCobro('todos'); }}
                                                    className={`px-3 py-1 rounded-md transition-all ${filtroTx === key ? active : 'text-slate-500 hover:text-slate-800'}`}>
                                                    {label}
                                                </button>
                                            ))}
                                        </div>
                                        {filtroCobro !== 'todos' && (
                                            <button type="button" onClick={() => setFiltroCobro('todos')}
                                                className="flex items-center gap-1.5 text-[8px] font-black uppercase px-2.5 py-1.5 rounded-md border bg-red-50 border-red-200 text-red-600">
                                                Filtro: {filtroCobro === 'vencida' ? 'Vencidas' : 'Pendientes de cobro'}
                                                <FaXmark className="text-[9px]" />
                                            </button>
                                        )}
                                    </div>
                                    <div className="flex items-center gap-3 flex-wrap">
                                        <div className="flex items-center gap-1.5">
                                            <span className="text-slate-500 font-bold uppercase text-[8px]">Desde:</span>
                                            <input type="date" value={fechaDesdeTx} onChange={e => setFechaDesdeTx(e.target.value)}
                                                className="bg-white border border-slate-200 rounded-md px-2.5 py-1 text-[9px] font-bold font-mono text-slate-600 focus:outline-none focus:ring-1 focus:ring-blue-500 transition-all" />
                                        </div>
                                        <div className="flex items-center gap-1.5">
                                            <span className="text-slate-500 font-bold uppercase text-[8px]">Hasta:</span>
                                            <input type="date" value={fechaHastaTx} onChange={e => setFechaHastaTx(e.target.value)}
                                                className="bg-white border border-slate-200 rounded-md px-2.5 py-1 text-[9px] font-bold font-mono text-slate-600 focus:outline-none focus:ring-1 focus:ring-blue-500 transition-all" />
                                        </div>
                                        {(fechaDesdeTx || fechaHastaTx) && (
                                            <button type="button" onClick={() => { setFechaDesdeTx(''); setFechaHastaTx(''); }}
                                                className="text-red-500 hover:text-red-700 font-black uppercase text-[8px] tracking-widest bg-red-50 hover:bg-red-100/60 border border-red-100 rounded-md px-2.5 py-1 transition-all">
                                                Limpiar Fechas
                                            </button>
                                        )}
                                    </div>
                                </div>

                                {transacciones.length > 0 && (
                                    <div className="px-6 py-3 bg-slate-800 flex items-center justify-between flex-wrap gap-3">
                                        <div>
                                            <p className="text-[8px] font-black uppercase text-slate-400 tracking-widest mb-0.5">
                                                {filtroTx === 'venta' ? 'Total ventas' : 'Total facturas'}
                                            </p>
                                            <p className="text-[20px] font-black text-white leading-none break-words">{fmtM(totalTxFiltrado)}</p>
                                            <div className="flex items-center gap-3 mt-1.5">
                                                <span className="text-[9px] font-bold text-slate-300">
                                                    Base: <span className="text-emerald-300 font-mono">{fmtM(baseTxFiltrada)}</span>
                                                </span>
                                                <span className="text-[9px] font-bold text-slate-300">
                                                    Imp: <span className="text-rose-300 font-mono">{fmtM(impuestosTxFiltrados)}</span>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {transaccionesFiltradas.length > 0 ? (
                                    <table className="w-full text-left border-collapse">
                                        <thead>
                                            <tr className="bg-blue-600">
                                                <th className="px-5 py-3 text-white text-[9px] font-black uppercase border-r border-blue-500">Tipo</th>
                                                <th className="px-5 py-3 text-white text-[9px] font-black uppercase border-r border-blue-500">Referencia</th>
                                                <th className="px-5 py-3 text-white text-[9px] font-black uppercase border-r border-blue-500 text-center">Fecha</th>
                                                <th className="px-5 py-3 text-white text-[9px] font-black uppercase border-r border-blue-500 text-right">Base Imponible</th>
                                                <th className="px-5 py-3 text-white text-[9px] font-black uppercase border-r border-blue-500 text-right">Total</th>
                                                <th className="px-5 py-3 text-white text-[9px] font-black uppercase border-r border-blue-500 text-center">Estado</th>
                                                <th className="px-5 py-3 text-white text-[9px] font-black uppercase text-center">Cobro</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-slate-50">
                                            {transaccionesFiltradas.map((tx, idx) => {
                                                const badge = badgeEstadoPago(tx);
                                                return (
                                                <tr key={`${tx.id}-${idx}`} className="hover:bg-blue-50/20 transition-colors">
                                                    <td className="px-5 py-2.5 border-r border-slate-50">
                                                        <span className={`text-[9px] font-black px-2.5 py-0.5 rounded-full border uppercase ${
                                                            tx.origen.includes('Venta')
                                                                ? 'text-indigo-600 bg-indigo-50 border-indigo-100'
                                                                : 'text-amber-600 bg-amber-50 border-amber-100'
                                                        }`}>
                                                            {tx.origen}
                                                        </span>
                                                    </td>
                                                    <td className="px-5 py-2.5 border-r border-slate-50">
                                                        <span className="text-[10px] font-bold text-slate-700 uppercase">{tx.referencia}</span>
                                                    </td>
                                                    <td className="px-5 py-2.5 border-r border-slate-50 text-center text-[9px] text-slate-500 font-mono">
                                                        {tx.fecha ? new Date(tx.fecha).toLocaleDateString('es-CO') : '—'}
                                                    </td>
                                                    <td className="px-5 py-2.5 border-r border-slate-50 text-right font-mono">
                                                        <span className="text-[10px] font-semibold text-emerald-600">{fmtM(tx.base_imponible)}</span>
                                                    </td>
                                                    <td className="px-5 py-2.5 border-r border-slate-50 text-right font-mono">
                                                        <span className="text-[10px] font-bold text-slate-700">{fmtM(tx.total)}</span>
                                                    </td>
                                                    <td className="px-5 py-2.5 border-r border-slate-50 text-center">
                                                        <span className={`text-[9px] font-black px-2.5 py-0.5 rounded-full border uppercase ${
                                                            ['sale', 'done', 'posted'].includes(tx.estado)
                                                                ? 'text-emerald-600 bg-emerald-50 border-emerald-100'
                                                                : ['draft', 'sent'].includes(tx.estado)
                                                                ? 'text-blue-500 bg-blue-50 border-blue-100'
                                                                : 'text-slate-400 bg-slate-50 border-slate-100'
                                                        }`}>
                                                            {tx.estado}
                                                        </span>
                                                    </td>
                                                    <td className="px-5 py-2.5 text-center">
                                                        {badge ? (
                                                            <span className={`text-[9px] font-black px-2.5 py-0.5 rounded-full border uppercase ${badge.className}`}>
                                                                {badge.label}
                                                            </span>
                                                        ) : (
                                                            <span className="text-[9px] text-slate-300">—</span>
                                                        )}
                                                    </td>
                                                </tr>
                                                );
                                            })}
                                        </tbody>
                                    </table>
                                ) : (
                                    <div className="text-center py-16 text-slate-300">
                                        <FaReceipt className="text-4xl mb-2 mx-auto block" />
                                        <p className="text-[11px] font-bold uppercase">
                                            No se encontraron transacciones {filtroTx === 'venta' ? 'de ventas' : 'de facturas'}
                                            {filtroCobro === 'pendiente' && ' pendientes de cobro'}
                                            {filtroCobro === 'vencida' && ' vencidas'}
                                            {' '}para este cliente.
                                        </p>
                                    </div>
                                )}
                            </div>
                        )}

{/* ── MODAL DE CREACIÓN / EDICIÓN DE OBSERVACIÓN ── */}
{visitaAEditar && (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4 animate-fadeIn">
        <div className="bg-white rounded-xl shadow-2xl border border-slate-100 w-full max-w-md p-6 relative">
            <button
                onClick={() => setVisitaAEditar(null)}
                className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1 transition-colors"
            >
                <FaXmark className="text-base" />
            </button>
            
            <div className="flex items-center gap-2 mb-4">
                <div className="p-2 bg-amber-50 text-amber-600 rounded-lg">
                    <FaCommentDots className="text-lg" />
                </div>
                <div>
                    <h3 className="text-[12px] font-black uppercase tracking-wider text-slate-800">
                        {visitaAEditar.comentarios || visitaAEditar.observaciones ? 'Editar Observación' : 'Nueva Observación'}
                    </h3>
                    <p className="text-[10px] text-slate-400 font-medium">
                        Visitador: <span className="font-bold text-slate-600">{visitaAEditar.nombre_visitador ?? '—'}</span>
                    </p>
                </div>
            </div>

            {/* Campo Textarea para escribir */}
            <div className="mb-4">
                <textarea
                    rows={4}
                    value={textoObservacion}
                    onChange={(e) => setTextoObservacion(e.target.value)}
                    placeholder="Escribe aquí las observaciones o notas de la visita..."
                    className="w-full text-[11px] p-3 text-slate-700 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-blue-500 focus:bg-white transition-all resize-none"
                />
            </div>

            <div className="flex justify-end gap-2">
                <button
                    type="button"
                    onClick={() => setVisitaAEditar(null)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-md text-[10px] font-black uppercase tracking-wider transition-all"
                >
                    Cancelar
                </button>
                <button
                    type="button"
                    disabled={guardandoObs}
                    onClick={handleGuardarObservacion}
                    className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-[10px] font-black uppercase tracking-wider transition-all active:scale-95 disabled:opacity-50"
                >
                    {guardandoObs ? <FaSpinner className="animate-spin text-xs" /> : <FaCheck className="text-xs" />}
                    Guardar
                </button>
            </div>
        </div>
    </div>
)}
{/* ── MODAL DE OBSERVACIONES DEL MÉDICO (perfil, no por visita) ── */}
{observacionMedicoAbierta && (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4 animate-fadeIn">
        <div className="bg-white rounded-xl shadow-2xl border border-slate-100 w-full max-w-md p-6 relative">
            <button
                onClick={() => setObservacionMedicoAbierta(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1 transition-colors"
            >
                <FaXmark className="text-base" />
            </button>

            <div className="flex items-center gap-2 mb-4">
                <div className="p-2 bg-amber-50 text-amber-600 rounded-lg">
                    <FaCommentDots className="text-lg" />
                </div>
                <div>
                    <h3 className="text-[12px] font-black uppercase tracking-wider text-slate-800">
                        {editandoObservacion 
                            ? (medico.observaciones ? 'Editar Observación' : 'Nueva Observación') 
                            : 'Vista Detalles de Observación'
                        }
                    </h3>
                    <p className="text-[10px] text-slate-400 font-medium">
                        Médico: <span className="font-bold text-slate-600">{medico.nombre} {medico.apellido}</span>
                    </p>
                </div>
            </div>

            <div className="mb-4">
                {/* Textarea habilitado únicamente como modo lectura si editandoObservacion === false */}
                <textarea
                    rows={6}
                    value={textoObservacionMedico}
                    readOnly={!editandoObservacion}
                    onChange={(e) => setTextoObservacionMedico(e.target.value)}
                    placeholder="Sin observaciones registradas..."
                    className={`w-full text-[11px] p-3 rounded-lg transition-all resize-none border ${
                        !editandoObservacion 
                            ? 'bg-slate-100 border-slate-200 text-slate-700 font-medium cursor-default focus:outline-none select-text' 
                            : 'bg-slate-50 border-slate-300 text-slate-800 focus:border-blue-500 focus:bg-white focus:outline-none'
                    }`}
                />
            </div>

            <div className="flex justify-end gap-2">
                {!editandoObservacion ? (
                    <>
                        <button
                            type="button"
                            onClick={() => setObservacionMedicoAbierta(false)}
                            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-md text-[10px] font-black uppercase tracking-wider transition-all"
                        >
                            Cerrar
                        </button>
                        <button
                            type="button"
                            onClick={() => setEditandoObservacion(true)}
                            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-[10px] font-black uppercase tracking-wider transition-all active:scale-95"
                        >
                            Editar
                        </button>
                    </>
                ) : (
                    <>
                        <button
                            type="button"
                            onClick={() => {
                                if (!medico.observaciones) {
                                    setObservacionMedicoAbierta(false);
                                } else {
                                    setEditandoObservacion(false);
                                    setTextoObservacionMedico(medico.observaciones ?? '');
                                }
                            }}
                            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-md text-[10px] font-black uppercase tracking-wider transition-all"
                        >
                            Cancelar
                        </button>
                        <button
                            type="button"
                            disabled={guardandoObsMedico}
                            onClick={handleGuardarObservacionMedico}
                            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-[10px] font-black uppercase tracking-wider transition-all active:scale-95 disabled:opacity-50"
                        >
                            {guardandoObsMedico ? <FaSpinner className="animate-spin text-xs" /> : <FaCheck className="text-xs" />}
                            Guardar
                        </button>
                    </>
                )}
            </div>
        </div>
    </div>
)}


                    </div>

                </div>
            </div>
        </PanelAdmin>
    );
}